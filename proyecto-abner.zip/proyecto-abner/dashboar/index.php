<?php
include "path.php";

if(isset($_SESSION["s_usuario"])){
    header('Location:'.BASE_URL.'views/dashboard.php');
}

?>
<!doctype html>
<html>

<head>
    <link rel="shortcut icon" href="<?php echo BASE_URL;?>img/unicla.png" />
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Iniciar Sesion UNICLA</title>

    <link rel="stylesheet" href="<?php echo BASE_URL;?>css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo BASE_URL;?>css/login.css">
    <link rel="stylesheet" href="<?php echo BASE_URL;?>css/sweetalert2.min.css">
    <link rel="stylesheet" type="text/css"
        href="<?php echo BASE_URL;?>css/material-design-iconic-font.min.css">
    <script src="https://kit.fontawesome.com/4d248b1a6c.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container-login">
        <div class="wrap-login">
            <form class="login-form validate-form" id="formLoginG" action="<?php echo BASE_URLB;?>models/loginG.php"
                method="post">
                <img src="<?php echo BASE_URL;?>img/unicla.png" class="rounded  mx-auto d-block" height="90"
                    alt="">
                <span class="login-form-title font-weight-bold">Bienvenidos Unicla </span>
                <span class="login-form-title">Inicia Sesion</span>

                <div class="wrap-input100" data-validate="Usuario incorrecto">
                    <input class="input100" type="text" id="usuario" name="usuario" placeholder="Usuario">
                    <span class="focus-efecto"></span>
                </div>

                <div class="wrap-input100" data-validate="Password incorrecto">
                    <input class="input100" type="password" id="password" name="password" placeholder="Password">
                    <span class="focus-efecto"></span>
                </div>

                <div class="container-login-form-btn">
                    <div class="wrap-login-form-btn">
                        <div class="login-form-bgbtn"></div>
                        <button type="submit" name="submit" class="login-form-btn">Iniciar Sesion</button>
                    </div>
                </div>
               
            
               
            </form>
        </div>
    </div>
    <div class="lds-ring loader " id="loader">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <script src="<?php echo BASE_URL;?>vendor/jquery/jquery-3.5.1.js"></script>
        <script src="<?php echo BASE_URL;?>vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo BASE_URL;?>vendor/jquery/popper.min.js"></script>
        <script src="<?php echo BASE_URL;?>vendor/jquery/sweetalert2.all.min.js"></script>
        <script src="<?php echo BASE_URL;?>js/codigo1.js"></script>
</body>

</html>