<?php

  $estudiante = $_POST["estudiante"];
	$fecha = $_POST["fecha"];
	$tipo = $_POST["tipo"];
	$descripcion = $_POST ["descripcion"];
	$directorio = "archivos/pse/";

	if (!file_exists($directorio)) 
      {
        mkdir($directorio, 0777, true);
      }

	$archivo = $directorio . basename($_FILES["file"]["name"]);

	$tipoArchivo = strtolower(pathinfo($archivo, PATHINFO_EXTENSION));

        if (move_uploaded_file($_FILES["file"] ["tmp_name"], $archivo)) {
          echo "archivo subido con exito";

        } else {
          echo "error en la subida del archivo";
        }

    $adjunto = $archivo;

    $sql = "INSERT INTO tabladelabasededatos (estudiante, fecha, tipo, descripcion, adjunto) values ('$estudiante', '$fecha', '$tipo', '$descripcion', '$adjunto')";

    $consulta = mysqli_query($conexion, $sql);

    if ($consulta==false) {
        echo "Error en la consulta";

        } else {
          echo "<br><br>Datos almacenados exitosamente<br><br>";
               }

    mysqli_close($conexion);
    echo "<a href ='" .$adjunto . "'>Descargar archivo</a>";




	?>