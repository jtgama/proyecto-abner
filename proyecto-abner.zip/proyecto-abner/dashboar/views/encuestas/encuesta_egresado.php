<?php
include '../../../dashboar/path.php';
include "../../../backend/conexion.php";
$objeto = new Conexion();
$conexion = $objeto->Conectar();
$query = "SELECT id as id, concat_ws(' - ', PROGRAMA, MODALIDAD) as programa FROM view_encuestas where estado = 'ACTIVO'";
$consulta = $conexion->prepare($query);
$consulta->setFetchMode(PDO::FETCH_ASSOC);
$consulta->execute();
$result = $consulta->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../../../dashboar/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/f…
[10:05 p. m., 25/8/2021] garridos: <!doctype html>
<html lang=" es">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

        <title>navbar con vue router</title>
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
        <script src="https://kit.fontawesome.com/4d248b1a6c.js" crossorigin="anonymous"></script>
        <link href="../../../dashboar/css/sb-admin-2.min.css" rel="stylesheet">
        <style>
        .contenedor {

            height: 100%;
            width: 100%;
            display: flex;
            position: fixed;
            align-items: center;
            justify-content: center;

        }



        .contacto {
            background-color: #304ffe;
        }

        .portafolio {
            background-color: #474747;
        }
        </style>

    </head>

<body>

    <div class="container pt-md-5 m-lg-5">

        <div class="row">

            <div class="col-xl-12">
                <div class="card ">
                    <h5 class="card-header h5 bg-warning text-light"> <i class="fas fa-clipboard-list"></i> ENCUESTA
                        EGRESADOS</h5>
                    <div class="card-body">
                        <h6 class="card-title text-center fw-bolder ">ENCUESTA PARA EGRESADOS </h6>
                        <p class="card-text font-italic text-justify"><strong> Apreciado Egresado:</strong> el programa
                            <strong>XXXXXXXXXXXXX </strong>, está realizando el proceso de autoevaluación, con el
                            propósito de identificar oportunidades de mejora. Para esta tarea, se ha diseñado la
                            presente encuesta, para recopilar información sobre la percepción que tiene usted sobre la
                            calidad del programa.

                            En el presente instrumento encontrará una serie de ítems (afirmaciones) que podrá calificar,
                            dependiendo de su nivel de percepción con respecto a cada uno de ellos, en una escala de
                            conformidad de 1 a 5 así:
                        </p>
                        <div class="d-flex justify-content-center">
                            <table class="table table-bordered animate_animated  animate_fadeInDown"
                                style="width:100px;">
                                <thead class="bg-dark text-white">
                                    <tr>
                                        <th>Grado de cumplimiento</th>
                                        <th>Conocimiento</th>
                                        <th>Rango</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center">
                                    <tr>

                                        <td>Plenamente</td>
                                        <td>Totalmente</td>
                                        <td>5</td>

                                    </tr>
                                    <tr>

                                        <td>En buen grado </td>
                                        <td>Buen grado</td>
                                        <td>4</td>
                                    </tr>
                                    <tr>

                                        <td>Aceptablemente </td>
                                        <td>Mediano grado</td>
                                        <td>3</td>
                                    </tr>
                                    <tr>

                                        <td>En bajo grado</td>
                                        <td>Poco</td>
                                        <td>2</td>
                                    </tr>
                                    <tr>

                                        <td>No se cumple</td>
                                        <td>Nada</td>
                                        <td>1</td>
                                    </tr>
                                    <tr>

                                        <td>No sabe</td>
                                        <td>No sabe</td>
                                        <td>0</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <p class="card-text font-italic text-justify">En el caso que alguno de los
                            ítems presentados sea de su total desconocimiento o
                            en caso de no contar con información para emitir un
                            juicio justo sobre la afirmación, podrá elegir la opción cero (0)
                            <strong>“No sabe o desconoce totalmente del tema referenciado”.</strong> <br><br>
                            De antemano se agradece su tiempo y colaboración en el diligenciamiento de este instrumento.

                        </p>
                        <form id="formUsuarios" method="POST" action="../../../backend/models/add_encuesta_egresado.php">

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="municip" class="col-form-label">Programa:</label>
                                        <select class="custom-select form-control text-uppercase" id="idPrograma"
                                            name="idPrograma" required>
                                            <option selected>Seleccione</option>
                                            <?php
                                        foreach ($result as $valores):
                                            echo '<option value="'.$valores['id'].'">'.$valores['programa'].'</option>';
                                            endforeach;
                                        ?>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class="d-flex justify-content-center ">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> * PROGRAMA DE EGRESADOS
                                            *</strong> </p>
                                    <table class="table table-bordered animate_animated  animate_fadeInDown"
                                        style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>
                                                    <p>1. ¿La institución responde a las expectativas de desarrollo de
                                                        la región?</p>
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="0" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="1" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="2" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="3" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="4" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="5" />
                                                </td>

                                            </tr>
                                            <tr>

                                                <td>2. ¿El plan de estudios desarrollado en el programa del cual usted
                                                    es Egresado(a) fue pertinente y actualizado contribuyendo a su
                                                    formación integral?
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="0" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="1" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="2" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="3" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="4" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>

                                                <td>3. ¿El desempeño de su ejercicio profesional le ha brindado
                                                    beneficios y reconocimientos sociales? </td>
                                                <td><input id="p3" name="p3" type="radio" value="0" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="1" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="2" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="3" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="4" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>4. ¿Ser Egresado de la Institución le ha representado una ventaja
                                                    competitiva en los procesos de selección laboral? </td>
                                                <td><input id="p4" name="p4" type="radio" value="0" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="1" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="2" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="3" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="4" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>5. ¿Existen canales de comunicación entre usted como egresado de
                                                    Unicaretiana, que le permitan estar enterado del acontecer
                                                    universitario?
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="0" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="1" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="2" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="3" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="4" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>6. ¿Conoce usted los espacios ofrecidos por la institución para su
                                                    participación como egresado en los organismos académicos y
                                                    administrativos?</td>
                                                <td><input id="p6" name="p6" type="radio" value="0" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="1" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="2" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="3" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="4" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p>7. ¿El programa académico del que egresó, brinda espacios en los
                                                        que usted puede exponer sus experiencias como profesional ante
                                                        los actuales estudiantes?</p>
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="0" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="1" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="2" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="3" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="4" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="5" />
                                                </td>

                                            </tr>
                                            <tr>

                                                <td>8. ¿La Uniclaretiana lo convoca para actividades de actualización
                                                    académicas (foros, seminarios, conferencias)?</td>
                                                <td><input id="p8" name="p8" type="radio" value="0" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="1" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="2" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="3" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="4" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>

                                                <td>9. ¿Las actividades de educación continua (diplomados, seminarios,
                                                    cursos y simposios de diferentes temas, y oferta del centro de
                                                    idiomas, entre otros) atienden a las necesidades formativas de la
                                                    región? </td>
                                                <td><input id="p9" name="p9" type="radio" value="0" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="1" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="2" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="3" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="4" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>10. ¿La institución interviene en los procesos de formación con
                                                        un enfoque diferencial y de género?</p>
                                                </td>
                                                <td><input id="p10" name="p10" type="radio" value="0" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="1" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="2" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="3" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="4" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>11. ¿Conoce usted los servicios ofrecidos por la Institución a
                                                        sus egresados?</p>
                                                </td>
                                                <td><input id="p11" name="p11" type="radio" value="0" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="1" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="2" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="3" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="4" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="5" /></td>

                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> Califique cada uno de los
                                            siguientes enunciados </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>12. Participa usted, como egresado, en eventos o actividades de
                                                    capacitación que la Uniclaretiana ofrece.
                                                </td>
                                                <td><input id="p12" name="p12" type="radio" value="0" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="1" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="2" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="3" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="4" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>13. Participa usted, como egresado, en espacios que brinda
                                                    Uniclaretiana para analizar los problemas asociados a la profesión.
                                                </td>
                                                <td><input id="p13" name="p13" type="radio" value="0" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="1" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="2" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="3" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="4" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>14. Participa, como egresado, de los servicios que le presta la
                                                        Uniclaretiana como: biblioteca, actividades culturales, entre
                                                        otros.
                                                    </p>
                                                </td>
                                                <td><input id="p14" name="p14" type="radio" value="0" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="1" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="2" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="3" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="4" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">

                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>15. ¿Uniclaretiana desarrolla el sentido de responsabilidad social
                                                    en sus egresados?
                                                </td>
                                                <td><input id="p15" name="p15" type="radio" value="0" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="1" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="2" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="3" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="4" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>16. ¿Existe correspondencia entre los contenidos de las asignaturas
                                                    que ofrecen los programas de la Universidad y los conocimientos que
                                                    se requieren para la práctica laboral?
                                                </td>
                                                <td><input id="p16" name="p16" type="radio" value="0" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="1" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="2" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="3" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="4" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>17. ¿Conoce de espacios de participación de los egresados, en los
                                                    programas para el análisis y ajuste de los planes de formación?
                                                </td>
                                                <td><input id="p17" name="p17" type="radio" value="0" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="1" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="2" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="3" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="4" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>18. ¿Considera usted que los medios de comunicación utilizados en
                                                    Uniclaretiana son suficientes para mantenerse informado respecto a
                                                    los asuntos institucionales de interés? </td>
                                                <td><input id="p18" name="p18" type="radio" value="0" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="1" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="2" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="3" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="4" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> Con el propósito de mejorar los procesos de formación de Uniclaretiana deseamos conocer su punto de vista sobre su desempeño personal en:</strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>19. La pertinencia científica del programa</td>
                                                <td><input id="p19" name="p19" type="radio" value="0" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="1" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="2" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="3" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="4" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>20. La pertinencia social del programa</td>
                                                <td><input id="p20" name="p20" type="radio" value="0" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="1" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="2" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="3" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="4" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>21. La correspondencia de su formación con su desempeño laboral</p>
                                                </td>
                                                <td><input id="p21" name="p21" type="radio" value="0" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="1" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="2" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="3" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="4" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>22. La calidad de la formación recibida en el programa</td>
                                                <td><input id="p22" name="p22" type="radio" value="0" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="1" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="2" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="3" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="4" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>23. Su satisfacción con respecto a la formación recibida</p>
                                                </td>
                                                <td><input id="p23" name="p23" type="radio" value="0" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="1" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="2" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="3" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="4" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>24. Habilidad  en competencias comunicativas, tecnológicas y manejo de segundo idioma</td>
                                                <td><input id="p24" name="p24" type="radio" value="0" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="1" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="2" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="3" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="4" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>25. Habilidad del egresado para el análisis y la  solución de problemas</p>
                                                </td>
                                                <td><input id="p25" name="p25" type="radio" value="0" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="1" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="2" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="3" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="4" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>26. La pertinencia de la formación recibida en el programa </td>
                                                <td><input id="p26" name="p26" type="radio" value="0" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="1" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="2" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="3" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="4" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>27. Su sentido de pertenencia con la Institución</td>
                                                <td><input id="p27" name="p27" type="radio" value="0" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="1" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="2" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="3" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="4" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>28. La satisfacción con respecto a sus expectativas laborales</td>
                                                <td><input id="p28" name="p28" type="radio" value="0" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="1" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="2" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="3" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="4" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>29. La relación de Uniclaretiana con sus egresados
                                                </td>
                                                <td><input id="p29" name="p29" type="radio" value="0" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="1" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="2" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="3" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="4" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>30. La correspondencia entre la ocupación y ubicación profesional de los egresados y el perfil de formación del programa</td>
                                                <td><input id="p30" name="p30" type="radio" value="0" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="1" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="2" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="3" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="4" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>31. Su contribución en la generación de empresas
                                                </td>
                                                <td><input id="p31" name="p31" type="radio" value="0" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="1" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="2" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="3" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="4" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>32. ¿Su formación contribuye a la solución de problemas que se presentan en su región o entorno?
                                                </td>
                                                <td><input id="p32" name="p32" type="radio" value="0" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="1" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="2" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="3" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="4" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                            <button type="submit" id="btnGuardar" name="btnGuardar" class="btn btn-dark">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/vue@2.x/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.js"></script>
    <script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
    <script src="../../../dashboar/vendor/jquery/jquery.min.js"></script>
    <script src="../../../dashboar/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../../../dashboar/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../../../dashboar/js/sb-admin-2.min.js"></script>

</body>

</html>