<?php
include '../path.php';
include_once '../../backend/conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();
if(!isset($_GET["id"])) exit();
$id = $_GET["id"];
$arrayDoc = $_GET["docActivo"];

$recibir_url = stripslashes($arrayDoc);
$recibir_url = urldecode($recibir_url );
$docActivo = unserialize($recibir_url);

var_dump($docActivo);

$consulta = "SELECT ID,PROGRAMA,MODALIDAD,RESOLUCION_RC,VENCIMENTO_RC,
AUTOEVALUCION1,PLAN_MEJORA_1,
SEGUIMIENTO_1,AUTOEVALUCION2,PLAN_MEJORA_2,SEGUIMIENTO_2,
RADICACION_SACES,INICIO_DOC_MAESTRO,DOC_MAESTRO FROM view_semaforo_rc WHERE ID = $id";
$resultado = $conexion->prepare($consulta);
$resultado->setFetchMode(PDO::FETCH_ASSOC);
$resultado->execute();

$data=$resultado->fetch(PDO::FETCH_ASSOC);


if (isset($_POST['actualizar'])) {

    $id2= trim($_POST['id']); 
   
     /* $seguimi1 = $_POST['segui1'];
    $planme2 = $_FILES['plan2']['name'];
    $seguimi2 = $_FILES['segui2']['name'];
    $docmaes = $_FILES['docmaes']['name'];*/
    
    
    $directorio = 'upload/';

    if (!file_exists($directorio)) 
      {
        mkdir($directorio, 0777, true);
      }
      if (!empty($_FILES["file"]["name"])) {

        $planme1  =  $_FILES["file"]["name"];
        $archivo = $directorio . basename($_FILES["file"]["name"]);

        $resulta = move_uploaded_file($_FILES["file"] ["tmp_name"], $archivo);
        $_POST['file'] = $planme1;                     
       

    } 
      $archivo1 = $directorio . basename($_FILES["file"]["name"]);
      $archivo2 = $directorio . basename($_FILES['segui1']['name']);
      $archivo3 = $directorio . basename($_FILES['plan2']['name']);
      $archivo4 = $directorio . basename( $_FILES['segui2']['name']);
      $archivo5 = $directorio . basename($_FILES['docmaes']['name']);

      $tipoArchivo = strtolower(pathinfo($archivo, PATHINFO_EXTENSION));
      if ( 
      move_uploaded_file($_FILES["file"] ["tmp_name"], $archivo1) ||
      move_uploaded_file($_FILES["segui1"] ["tmp_name"], $archivo2) || 
      move_uploaded_file($_FILES["plan2"] ["tmp_name"], $archivo3) ||
      move_uploaded_file($_FILES["segui2"] ["tmp_name"], $archivo4) ||
      move_uploaded_file($_FILES["docmaes"] ["tmp_name"], $archivo5)
      
      ) {
      
        echo "archivo subido con exito";

      } else {
        echo "error en la subida del archivo";
      }
      $consulta = "UPDATE semaforo_rc SET PLAN_MEJORA_1 = ?, SEGUIMIENTO_1 = ? , PLAN_MEJORA_2 = ?, SEGUIMIENTO_2 = ?, DOC_MAESTRO = ? WHERE ID = ?";

      //$consulta = "UPDATE semaforo_rc SET PLAN_MEJORA_1 = ?, SEGUIMIENTO_1 = ? , PLAN_MEJORA_2 = ?, SEGUIMIENTO_2 = ?, DOC_MAESTRO = ? WHERE ID = ?";

        if ($docActivo[0] == 0){
            $archivo1 = 'NULL';
        }
        if ($docActivo[1] == 0){
            $archivo2 = 'NULL';
        }
        if ($docActivo[2] == 0){
            $archivo3 = 'NULL';
        }
        if ($docActivo[3] == 0){
            $archivo4 = 'NULL';
        }
        if ($docActivo[4] == 0){
            $archivo5 = 'NULL';
        }

        $resultado = $conexion->prepare($consulta);
        $resultado2 =  $resultado->execute([$archivo1,$archivo2,$archivo3,$archivo4,$archivo5,$id2]); # Pasar en el mismo orden de los ?
        $resultado->closeCursor();   
        
       

       
        
        if($resultado->rowCount() > 0)
        {
        $count = $resultado->rowCount();
       
        header("Location: " . "listar_programas.php");
        echo "<div class='content alert alert-primary' >
        Gracias: $count registro ha sido actualizado </div>";
        }
        else{
        echo "<div class='content alert alert-danger'> No se pudo actulizar el registro </div>";
        print_r($resultado->errorInfo()); 
        }  
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../datatables/datatables.min.css" />
    <link href="../datatables/DataTables-1.10.23/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="../datatables/responsive.bootstrap4.min.css" rel="stylesheet">
    <!--datables estilo bootstrap 4 CSS-->
    <link rel="stylesheet" type="text/css" href="../datatables/DataTables-1.10.23/css/dataTables.bootstrap4.min.css">

</head>

<body id="page-top">

    <div id="wrapper">
        <?php  include_once ("sidebar.php");?>
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <?php  include_once ("nav.php");?>
                <div class="container-fluid">
                    <div class="container caja">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive">
                                    <div class="table-responsive">
                                        <form id="formaAdmin" method="POST" class="form-neon" autocomplete="off" enctype="multipart/form-data">
                                            <input type="hidden" name="id" id="id" value="<?php echo $data['ID']?>">
                                            <table id="tablaUsuarios"
                                                class="table table-striped table-bordered table-condensed dt-responsive nowrap animate__animated  animate__fadeInDown"
                                                style="width:100%">
                                                <thead class="text-center bg-success text-white">
                                                    <tr>
                                                        <th>#</th>
                                                        <th>PROGRAMA</th>
                                                        <th>MODALIDAD</th>
                                                        <th>RESOLUCION_RC</th>
                                                        <th>VENCIMENTO_RC</th>
                                                        <th>AUTOEVALUCION1</th>
                                                        <th>PLAN_MEJORA_1</th>
                                                        <th>SEGUIMIENTO_1</th>
                                                        <th>AUTOEVALUCION2</th>
                                                        <th>PLAN_MEJORA_2</th>
                                                        <th>SEGUIMIENTO_2</th>
                                                        <th>RADICACION_SACES</th>
                                                        <th>INICIO_DOC_MAESTRO</th>
                                                        <th>DOC_MAESTRO</th>
                                                        <th>SUBIR DOCUMENTOS</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td><?php echo $data['ID']; ?></td>
                                                        <td><?php echo $data['PROGRAMA'];?></td>
                                                        <td><?php echo $data['MODALIDAD'];?></td>
                                                        <td><?php echo $data['RESOLUCION_RC'];?></td>
                                                        <td><?php echo $data['VENCIMENTO_RC'];?></td>
                                                        <td><?php echo $data['AUTOEVALUCION1'];?></td>
                                                        <td>
                                                            <input type="file" name="file" id="file" value="<?php echo $data['PLAN_MEJORA_1'];?>" accept=".xlsx, .docx, .doc, .pdf, .pptx" >
                                                        </td>
                                                        <td><input type="file" name="segui1" id="segui1" accept=".xlsx, .docx, .doc, .pdf, .pptx"></td>
                                                        <td><?php echo $data['AUTOEVALUCION2'];?></td>
                                                        <td><input type="file" name="plan2" id="plan2" accept=".xlsx, .docx, .doc, .pdf, .pptx"></td>
                                                        <td><input type="file" name="segui2" id="segui2" accept=".xlsx, .docx, .doc, .pdf, .pptx"></td>
                                                        <td><?php echo $data['RADICACION_SACES'];?></td>
                                                        <td><?php echo $data['INICIO_DOC_MAESTRO'];?></td>
                                                        <td><input type="file" name="docmaes" id="docmaes" accept=".xlsx, .docx, .doc, .pdf, .pptx" ></td>

                                                        <td>
                                                            <button type="submit" class="btn btn-raised btn-info btn-sm"
                                                                 id="actualizar" name="actualizar"><i
                                                                    class="far fa-save"></i> &nbsp; CARGAR</button>
                                                        </td>

                                                    </tr>

                                                </tbody>
                                            </table>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                </div>
                <?php  include_once ("footer.php");?>
            </div>

        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">¿Listo para salir?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Seleccione <strong>"Cerrar sesión"</strong> a continuación si está listo
                    para
                    finalizar su sesión actual.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-primary" href="login.html">Cerrar Sesion</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->

    <script src="https://cdn.jsdelivr.net/npm/vue@2.x/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.js"></script>
    <script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script type="text/javascript" src="../datatables/datatables.min.js"></script>
    <script src="../datatables/responsive.bootstrap4.min.js"></script>
    <script src="../datatables/dataTables.responsive.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        var user_id, opcion;
        opcion = 4;

        tablaUsuarios = $('#tablaUsuarios').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros",
                "zeroRecords": "No se encontraron resultados",
                "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sSearch": "Buscar:",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast": "Último",
                    "sNext": "Siguiente",
                    "sPrevious": "Anterior"
                },
                "sProcessing": "Cargando...",
            },
            responsive: true


        });
    });
    </script>
</body>

</html>