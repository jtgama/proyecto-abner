<ul class="navbar-nav bg-gradient-info sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
    <div class="sidebar-brand-icon rotate-n-15">
        <img src="http://localhost/proyecto-abner/dashboar/img/unicla.png" width="30" height="30" alt="">
    </div>
    <div class="sidebar-brand-text mx-3"> Admin <sup>Unicla</sup></div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <router-link to="/" class="nav-link">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Panel Administrativo</span>
    </router-link>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Interfaces
</div>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">

    <a href="#" class="nav-link collapsed" data-toggle="collapse" data-target="#collapseTwo"
        aria-expanded="true" aria-controls="collapseTwo">
        <i class="fas fa-traffic-light"></i>
        <span>Semáforo</span>
    </a>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
        <a href="<?php echo BASE_URL ?>views/add_acabacom_dev.php" class="collapse-item">
                <i class="far fa-plus-square"></i>
                <span>Crear RC</span></a>

            <a href="<?php echo BASE_URL ?>views/listar_programas.php" class="collapse-item">
                <i class="fas fa-clipboard-list"></i>
                <span>Consultar RC</span></a>
        </div>
    </div>
</li>


<!-- Nav Item - Utilities Collapse Menu  <i class="fas fa-fw fa-wrench"></i> -->
<li class="nav-item">

    <a href="#" class="nav-link collapsed" data-toggle="collapse" data-target="#collapseUtilities"
        aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-traffic-light"></i>
        <span>Indicadores</span></a>
    <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
        data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a href="<?php echo BASE_URL ?>views/add_indicador.php" class="collapse-item">
                <i class="fas fa-fw fa-table"></i>
                <span>Crear Indicador</span></a>

            <a href="<?php echo BASE_URL ?>views/add_indicadores.php" class="collapse-item">
                <i class="fas fa-fw fa-table"></i>
                <span>Consultar Indicador</span></a>

        </div>
    </div>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Complementos
</div>

<!-- Nav Item - Pages Collapse Menu -->


<!-- Nav Item - Charts -->


<!-- Nav Item - Tables -->
<li class="nav-item">

    <a href="#" class="nav-link collapsed" data-toggle="collapse" data-target="#collapseUtilities1"
        aria-expanded="true" aria-controls="collapseUtilities1">
        <i class="fas fa-traffic-light"></i>
        <span>Encuesta</span></a>
    <div id="collapseUtilities1" class="collapse" aria-labelledby="headingUtilities"
        data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a href="<?php echo BASE_URL ?>views/add_encuesta.php" class="collapse-item">
                <i class="fas fa-fw fa-table"></i>
                <span>Crear Encuesta</span></a>
            <a href="<?php echo BASE_URL ?>views/consultar_encuestas.php" class="collapse-item">
                <i class="fas fa-fw fa-table"></i>
                <span>Consultar Encuesta</span></a>
        </div>
    </div>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

<!-- Sidebar Message -->
<div class="sidebar-card">
    <img class="sidebar-card-illustration mb-2" src="<?php echo BASE_URL ?>img/unicla.png" alt="">
    <p class="text-center mb-2"><strong>Bienvenidos</strong> al nuevo portal</p>

</div>

</ul>