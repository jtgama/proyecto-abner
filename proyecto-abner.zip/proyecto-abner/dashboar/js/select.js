$(document).ready(function () {
    /* --variables para llamar a los select por el id */
    let $condicion = document.getElementById('condiciones')
    let $indicador = document.getElementById('indicadores')
    let $modalidad = document.getElementById('modalidades')
    let $programa = document.getElementById('programas')
    
    function cargarModalidad() {
        $.ajax({
            url: '../../backend/models/consultaprograma.php',
            type: 'GET',
            success: function(response) {
                const modalidades = JSON.parse(response);
                let template = '<option class="form-control" selected disabled>-- Seleccione --</option>'
    
                modalidades.forEach(modalidad => {
                    template += `<option class="form-control" value="${modalidad.codModali}">${modalidad.nomModali}</option>`;
                })

                $modalidad.innerHTML = template;
            }
        })
    }
    cargarModalidad()

    function cargarPrograma(sendDatos2) {
        $.ajax({
            url: '../../backend/models/consultaprograma.php',
            type: 'POST',
            data: sendDatos2,
            success: function(data) {
                const respuestas2 = JSON.parse(data);
                let template = '<option class="form-control" selected disabled>-- Seleccione --</option>'
    
                respuestas2.forEach(respuesta2 => {
                    template += `<option class="form-control" value="${respuesta2.codProgra}"> ${respuesta2.nomProgra}</option>`;
                })

                $programa.innerHTML = template;
            }
        })
    }
    $modalidad.addEventListener('change', () => {
        const codmodalidad = $modalidad.value

        const sendDatos2 = {
            'codPrograma': codmodalidad
        }
        
        cargarPrograma(sendDatos2)

        
    })



    function cargarCondiciones() {
        $.ajax({
            url: '../../backend/models/select.php',
            type: 'GET',
            success: function(response) {
                const condiciones = JSON.parse(response);
                let template = '<option class="form-control" selected disabled>-- Seleccione --</option>'
    
                condiciones.forEach(condicion => {
                    template += `<option class="form-control" value="${condicion.codCondicion}">${condicion.nomCondicion}</option>`;
                })

                $condicion.innerHTML = template;
            }
        })
    }
    cargarCondiciones()

    function cargarindicador(sendDatos) {
        $.ajax({
            url: '../../backend/models/select.php',
            type: 'POST',
            data: sendDatos,
            success: function(response) {
                const respuestas = JSON.parse(response);
                let template = '<option class="form-control" selected disabled>-- Seleccione --</option>'
    
                respuestas.forEach(respuesta => {
                    template += `<option class="form-control" value="${respuesta.codIndicador}">${respuesta.nomIndicador}</option>`;
                })

                $indicador.innerHTML = template;
            }
        })
    }
    $condicion.addEventListener('change', () => {
        const codcondicion = $condicion.value

        const sendDatos = {
            'codigoIndica': codcondicion
        }
        
        cargarindicador(sendDatos)

        
    })
   
})