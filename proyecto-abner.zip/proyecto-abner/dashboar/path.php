<?php 
session_start();
  define("ROOT_PATH", realpath(dirname(__FILE__)));
  define("BASE_URL", "http://localhost/proyecto-abner/dashboar/");
  define("BASE_URLB", "http://localhost/proyecto-abner/backend/");
  define("BASE_INDEX", "http://localhost/proyecto-abner/dashboar/");
  define("BASE_LOGIN", "http://localhost/proyecto-abner/dashboar/");
  date_default_timezone_set('America/Bogota');
  setlocale(LC_TIME, 'es_ES.UTF-8');

 ?>