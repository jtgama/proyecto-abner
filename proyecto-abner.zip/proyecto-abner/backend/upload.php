<?php
$_POST = json_decode(file_get_contents("php://input"), true);

function permisos() {  
  if (isset($_SERVER['HTTP_ORIGIN'])){
      header("Access-Control-Allow-Origin: *");
      header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
      header("Access-Control-Allow-Headers: Origin, Authorization, X-Requested-With, Content-Type, Accept");
      header('Access-Control-Allow-Credentials: true');      
  }  
  if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS'){
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))          
        header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: Origin, Authorization, X-Requested-With, Content-Type, Accept");
    exit(0);
  }
}
permisos();
//upload.php

$archivo = '';
$archivo2 = '';

if(isset($_FILES['file']['name']))
{
$formato = $_FILES['file']['type'];
 $archivo_name = $_FILES['file']['name'];
 $valid_extensions = array("xlsx", "docx", "doc", "pdf","pptx");
 $extension = pathinfo($archivo_name, PATHINFO_EXTENSION);
 if(in_array($extension, $valid_extensions))
 {
  $upload_path = 'upload/' . time() . '.' . $extension;
  if(move_uploaded_file($_FILES['file']['tmp_name'], $upload_path))
  {
   $message = 'Documento cargado';
   if (strpos($upload_path,"docx") || strpos($upload_path,"doc")) {
    $archivo2 ='<i class="fas fa-file-word fa-5x" style="color: #18B6D3;"></i>';
    $archivo = $archivo_name;
   }
   elseif(strpos($upload_path,"pdf") ){
    $archivo2 ='<i class="fas fa-file-pdf fa-5x" style="color: red;"></i>';
    $archivo = $archivo_name;
   }
   elseif(strpos($upload_path,"xlsx") ){
    $archivo2 ='<i class="fas fa-file-excel fa-5x" style="color: green;"></i>';
    $archivo = $archivo_name;
   }
   elseif(strpos($upload_path,"pptx") ){
    $archivo2 ='<i class="fas fa-file-powerpoint fa-5x" style="color: orange;"></i>';
    $archivo = $archivo_name;
   }
  }
  else
  {
   $message = 'Hay un error al cargar la Documento.';
  }
 }
 else
 {
  $message = 'Solo se pueden cargar documentos .xlsx, .docx, .doc, .pdf, .pptx"';
 }
}
else
{
 $message = 'Seleccione Documento';
}

$output = array(
 'message'  => $message,
 'archivo'   => $archivo,
 'archivo2'  => $archivo2
);

echo json_encode($output);


?>