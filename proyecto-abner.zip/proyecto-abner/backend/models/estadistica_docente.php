<?php
include_once '../conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

//if (isset($_POST['btnGuardar'])) {
    $fecha_ini = "2022/01/01";//trim($_POST['fecha_ini']);
    //$convert_fini = date("Y-m-d", strtotime($fecha_ini));
    $fecha_fin = "2022/06/01";//trim($_POST['fecha_fin']);
    //$convert_ffin = date("Y-m-d", strtotime($fecha_fin));
    $tipDocente = "PLANTA";
    $programa = 1;
    $registros = 0;
    $cero = 0;
    $uno = 0;
    $dos = 0;
    $tres = 0;
    $cuatro = 0;
    $cinco = 0;
    $consulta = "SELECT * FROM acabacom_acabacom_dev.encuesta_docentes est
	INNER JOIN acabacom_acabacom_dev.encuestas enc
    ON est.ENCUESTAS_ID = enc.ID
    WHERE enc.PROGRAMA_ID = '$programa'
    AND est.FCHA_CREACION BETWEEN '$fecha_ini' AND '$fecha_fin'";
    $resultado = $conexion->prepare($consulta);
    $resultado->setFetchMode(PDO::FETCH_ASSOC);
    $resultado->execute();
    $data=$resultado->fetchAll();
    //echo sizeof($data);
    //echo $row['P1.1'], "  ", $row['P1.2'], "<br>";
    $i = 0;
    foreach ($data as $row) {
        $response[$i][0] = $row['P1.1'];
        $response[$i][1] = $row['P1.2'];
        $response[$i][2] = $row['P1.3'];
        $response[$i][3] = $row['P1.4'];
        $response[$i][4] = $row['P1.5'];
        $response[$i][5] = $row['P1.6'];
        $response[$i][6] = $row['P1.7'];
        $response[$i][7] = $row['P1.8'];
        $response[$i][8] = $row['P1.9'];
        $response[$i][9] = $row['P1.10'];
        $response[$i][10] = $row['P1.11'];
        $response[$i][11] = $row['P1.12'];
        $response[$i][12] = $row['P2.1'];
        $response[$i][13] = $row['P2.2'];
        $response[$i][14] = $row['P2.3'];
        $response[$i][15] = $row['P2.4'];
        $response[$i][16] = $row['P2.5'];
        $response[$i][17] = $row['P2.6'];
        $response[$i][18] = $row['P2.7'];
        $response[$i][19] = $row['P2.8'];
        $response[$i][20] = $row['P2.9'];
        $response[$i][21] = $row['P2.10'];
        $response[$i][22] = $row['P2.11'];
        $response[$i][23] = $row['P2.12'];
        $response[$i][24] = $row['P2.13'];
        $response[$i][25] = $row['P2.14'];
        $response[$i][26] = $row['P2.15'];
        $response[$i][27] = $row['P2.16'];
        $response[$i][28] = $row['P2.17'];
        $response[$i][29] = $row['P2.18'];
        $response[$i][30] = $row['P2.19'];
        $response[$i][31] = $row['P2.20'];
        $response[$i][32] = $row['P2.21'];
        $response[$i][33] = $row['P2.22'];
        $response[$i][34] = $row['P2.23'];
        $response[$i][35] = $row['P2.24'];
        $response[$i][36] = $row['P2.25'];
        $response[$i][37] = $row['P2.26'];
        $response[$i][38] = $row['P2.27'];
        $response[$i][39] = $row['P2.28'];
        $response[$i][40] = $row['P2.29'];
        $i++;
    }

    for ($c = 0; $c < 41; $c++){
        for ($f = 0; $f < sizeof($data); $f++){
            switch($response[$f][$c]) {
                case 0:
                    $cero++;
                break;
                case 1:
                    $uno++;
                break;
                case 2:
                    $dos++;
                break;
                case 3:
                    $tres++;
                break;
                case 4:
                    $cuatro++;
                break;
                case 5:
                    $cinco++;
                break;
            }
        }
        $rta[$c][0] = $cero;
        $rta[$c][1] = $uno;
        $rta[$c][2] = $dos;
        $rta[$c][3] = $tres;
        $rta[$c][4] = $cuatro;
        $rta[$c][5] = $cinco;
        $cero = 0;
        $uno = 0;
        $dos = 0;
        $tres = 0;
        $cuatro = 0;
        $cinco = 0;
    }

    /*for ($f = 0; $f < sizeof($data); $f++){
        for ($c = 0; $c < 46; $c++){
            echo $response[$f][$c], " - ";
        }
        echo "<br>";
    }*/
    echo "Respuestas: ", "0", " || ", "1", " || ", "2", " || ", "3", " || ", "4", " || ", "5";
    echo "<br>";
    for ($f = 0; $f < sizeof($rta); $f++){
        echo "Pregunta ", ($f+1), ": ";
        for ($c = 0; $c < 6; $c++){
            echo $rta[$f][$c], " - ";
        }
        echo "<br>";
    }


//}else{
    //echo 'Error';
//}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;