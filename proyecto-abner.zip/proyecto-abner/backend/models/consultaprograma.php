<?php

include "../conexion.php";


function obtenerModalidad() {
    $objeto = new Conexion();
    $conexion = $objeto->Conectar();
    $query = "SELECT * FROM modalidad";
    $result = $conexion->query($query);

    $json = array();
    
    while($row = $result->fetch()) {
        $json[] = array(
            'codModali' => $row['ID'],
            'nomModali' => $row['NOMBRE'],
        );
    }  

    $jsonstring = json_encode($json);
    echo $jsonstring;
}
function obtenerPrograma($modalidad_id) {
    $objeto = new Conexion();
    $conexion = $objeto->Conectar();
    $query = "SELECT * FROM programa WHERE MODALIDAD_ID = $modalidad_id";
    $result = $conexion->query($query);

    $json = array();
    
    while($row = $result->fetch()) {
        $json[] = array(
            'codProgra' => $row['ID'],
            'nomProgra' => $row['NOMBRE'],
        );
    }  

    $jsonstring = json_encode($json);
    echo $jsonstring;
}

if( isset($_POST['codPrograma']) ) {
    $modalidad_id = $_POST['codPrograma'];
    obtenerPrograma($modalidad_id);

} 
else{
    obtenerModalidad();        
}