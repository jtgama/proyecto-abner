<?php
include_once '../conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

if (isset($_POST['btnGuardar'])) {
    echo 'ok';
    $idPrograma = trim($_POST['idPrograma']);
    $fecha_RC = trim($_POST['fecha_ini']);
    $convert_fRC = date("Y-m-d", strtotime($fecha_RC));

    $consulta = "call acabacom_dev.add_evidencias(?, ?, @pRESULTADO)";
    $resultado = $conexion->prepare($consulta);
    $resultado->bindParam(1, $pIdPrograma);
    $resultado->bindParam(2, $pConvert_fRC);
    $pIdPrograma = (int) $idPrograma;
    $pConvert_fRC = $convert_fRC;
    $resultado->execute(); 
    $resultado->closeCursor();
    $r = $conexion->query('select @pResultado'); 
    $result = $r->fetchColumn();
    echo $result;
}else{
    echo 'Error';
}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;