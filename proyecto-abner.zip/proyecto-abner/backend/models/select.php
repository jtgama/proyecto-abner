<?php
include "../conexion.php";

 


function obtenerCondiciones() {
    $objeto = new Conexion();
    $conexion = $objeto->Conectar();
    $query = "SELECT * FROM condiciones";
    $result = $conexion->query($query);
   
     $json = array();
     
     while($row = $result->fetch()) {
         $json[] = array(
             'codCondicion' => $row['ID'],
             'nomCondicion' => $row['CONDICION'],
         );
     }  
 
     $jsonstring = json_encode($json);
     echo $jsonstring;
 }
 
 

    function  obtenerIndicadores($codIndicadores) {
       
        $objeto = new Conexion();
        $conexion = $objeto->Conectar();

        $query = "SELECT * FROM indicador WHERE CONDICIONES_ID = $codIndicadores";
        $result = $conexion->query($query);

        $json = array();
        
        while($row = $result->fetch()) {
            $json[] = array(
                'codIndicador' => $row['ID'],
                'nomIndicador' => $row['INDICADOR'],
            );
        }

        $jsonstring = json_encode($json);
        echo $jsonstring;
    }

    
    if( isset($_POST['codigoIndica']) ) {
        $codIndicadores = $_POST['codigoIndica'];
        obtenerIndicadores($codIndicadores);
   
    } 
    else{
        obtenerCondiciones();        
    }
?>