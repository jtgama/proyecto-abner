<?php
include_once '../conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

if (isset($_POST['btnGuardar'])) {
    echo 'ok';
    $idPrograma = trim($_POST['idPrograma']);
    $fecha_ini = trim($_POST['fecha_ini']);
    $convert_fini = date("Y-m-d", strtotime($fecha_ini));
    $fecha_fin = trim($_POST['fecha_fin']);
    $convert_ffin = date("Y-m-d", strtotime($fecha_fin));

    $consulta = "call acabacom_dev.add_encuestas(?, ?, ?, @pRESULTADO)";
    $resultado = $conexion->prepare($consulta);
    $resultado->bindParam(1, $pIdPrograma);
    $resultado->bindParam(2, $convert_fini);
    $resultado->bindParam(3, $convert_ffin);
    $pIdPrograma = (int) $idPrograma;
    $pConvert_fini = $convert_fini;
    $pConvert_ffin = $convert_ffin;
    $resultado->execute(); 
    $resultado->closeCursor();
    $r = $conexion->query('select @pResultado'); 
    $result = $r->fetchColumn();
    echo $result;
}else{
    echo 'Error';
}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;