<?php
include "../../backend/conexion.php";
$objeto = new Conexion();
$conexion = $objeto->Conectar();


if (isset($_POST['btnGuardar'])) {

 $programa = $_POST['programas'];
 $condicion = $_POST['condiciones'];
 $indicador = $_POST['indicadores'];
  $modalidad = $_POST['modalidades'];

    $query = "SELECT inds.ID AS ID, cnd.CONDICION AS CONDICION, 
    ind.INDICADOR AS INDICADOR, 
    moda.NOMBRE AS MODALIDAD,
    prm.NOMBRE AS PROGRAMA, 
    inds.DOCUMENTO AS DOCUMENTO 
    FROM acabacom_dev.indicadores inds
    INNER JOIN acabacom_dev.indicador ind ON inds.INDICADOR_ID = ind.ID
    INNER JOIN acabacom_dev.condiciones cnd ON ind.CONDICIONES_ID = cnd.ID
    INNER JOIN acabacom_dev.evidencias evi ON inds.EVIDENCIAS_ID = evi.ID
    INNER JOIN acabacom_dev.programa prm ON evi.PROGRAMA_ID = prm.ID
    INNER JOIN acabacom_dev.modalidad moda ON prm.ID = moda.ID
    WHERE moda.ID = '".$modalidad."' AND prm.ID = '".$programa."' AND cnd.ID = '".$condicion."' AND ind.ID = '".$indicador."'";
    $result = $conexion->query($query);

    $json = array();
    
    while($row = $result->fetch()) {
        $json[] = array(
            'idindica' => $row['ID'],
            'modalidad' => $row['MODALIDAD'],
            'programa' => $row['PROGRAMA'],
            'condicion' => $row['CONDICION'],
            'indicador' => $row['INDICADOR'],
            'documento' => $row['DOCUMENTO'],
        );
    }

    $jsonstring = json_encode($json);
    #echo $jsonstring;
}
else if(isset($_POST['btnGuardarA'])){   
    setlocale(LC_TIME, "spanish");
    $id2= trim($_POST['id']);
    $directorio = 'upload/';
    
    

    $today = strftime("%d de %B de %Y");
    if (!file_exists($directorio)) 
      {
        mkdir($directorio, 0777, true);
      }
      
        $planme1  =  $_FILES["file"]["name"];
        $archivo = $today ." - ". basename($_FILES["file"]["name"]);
    
        $resulta = move_uploaded_file($_FILES["file"] ["tmp_name"], $archivo);

        if ($resulta) {
            echo "archivo subido con exito";
        }
        else{
            echo "error en la subida del archivo";
        }          
        
        $consulta = "UPDATE acabacom_dev.indicadores set DOCUMENTO = ? Where ID = ?";
        $resultado = $conexion->prepare($consulta);
        $resultado2 =  $resultado->execute([$archivo,$id2]); # Pasar en el mismo orden de los ?
        $resultado->closeCursor();   
        
       

       
        
        if($resultado->rowCount() > 0)
        {
        $count = $resultado->rowCount();
       
        header("Location: " . "add_indicadores.php");
        echo "<div class='content alert alert-primary' >
        Gracias: $count registro ha sido actualizado </div>";
        }
        else{
        echo "<div class='content alert alert-danger'> No se pudo actulizar el registro </div>";
        print_r($resultado->errorInfo()); 
        } 
}
       

?>