<?php
include_once '../conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

if (isset($_POST['btnGuardar'])) {
    echo 'ok';
    $nis = trim($_POST['nis']);
    $idPrograma = trim($_POST['idPrograma']);
    $codRC = trim($_POST['codRC']);
    $fecha_RC = trim($_POST['fecha_RC']);
    $convert_fRC = date("Y-m-d", strtotime($fecha_RC));

    $consulta = "call acabacom_dev.add_semaforo_rc(?, ?, ?, ?, @pRESULTADO)";
    $resultado = $conexion->prepare($consulta);
    $resultado->bindParam(1, $pNis);
    $resultado->bindParam(2, $pIdPrograma);
    $resultado->bindParam(3, $pCodRC);
    $resultado->bindParam(4, $pConvert_fRC);
    $pNis = (int) $nis;
    $pIdPrograma = (int) $idPrograma;
    $pCodRC = $codRC;
    $pConvert_fRC = $convert_fRC;
    $resultado->execute(); 
    $resultado->closeCursor();
    $r = $conexion->query('select @pResultado'); 
    $result = $r->fetchColumn();
    echo $result;
}else{
    echo 'Error';
}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;