<?php
include_once '../conexion.php';
require_once '../excel/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;
$spreadsheet = new SpreadSheet();
$objeto = new Conexion();
$conexion = $objeto->Conectar();

//if (isset($_POST['btnGuardar'])) {
    $fecha_ini = "2022/01/01";//trim($_POST['fecha_ini']);
    //$convert_fini = date("Y-m-d", strtotime($fecha_ini));
    $fecha_fin = "2022/06/01";//trim($_POST['fecha_fin']);
    //$convert_ffin = date("Y-m-d", strtotime($fecha_fin));
    $programa = 1;
    $registros = 0;
    $cero = 0;
    $uno = 0;
    $dos = 0;
    $tres = 0;
    $cuatro = 0;
    $cinco = 0;
    $consulta = "SELECT * FROM acabacom_dev.encuesta_administrativos est
	INNER JOIN acabacom_dev.encuestas enc
    ON est.ENCUESTAS_ID = enc.ID
    WHERE enc.PROGRAMA_ID = '$programa'
    AND est.FCHA_CREACION BETWEEN '$fecha_ini' AND '$fecha_fin'";
    $resultado = $conexion->prepare($consulta);
    $resultado->setFetchMode(PDO::FETCH_ASSOC);
    $resultado->execute();
    $data=$resultado->fetchAll();
    //echo sizeof($data);
    //echo $row['P1.1'], "  ", $row['P1.2'], "<br>";
    $i = 0;
    foreach ($data as $row) {
        $response[$i][0] = $row['P1'];
        $response[$i][1] = $row['P2'];
        $response[$i][2] = $row['P3'];
        $response[$i][3] = $row['P4'];
        $response[$i][4] = $row['P5'];
        $response[$i][5] = $row['P6'];
        $response[$i][6] = $row['P7'];
        $response[$i][7] = $row['P8'];
        $response[$i][8] = $row['P9'];
        $response[$i][9] = $row['P10'];
        $response[$i][10] = $row['P11'];
        $response[$i][11] = $row['P12'];
        $response[$i][12] = $row['P13'];
        $response[$i][13] = $row['P14'];
        $response[$i][14] = $row['P15'];
        $response[$i][15] = $row['P16'];
        $response[$i][16] = $row['P17'];
        $response[$i][17] = $row['P18'];
        $response[$i][18] = $row['P19'];
        $response[$i][19] = $row['P20'];
        $response[$i][20] = $row['P21'];
        $response[$i][21] = $row['P22'];
        $response[$i][22] = $row['P23'];
        $response[$i][23] = $row['P24'];
        $response[$i][24] = $row['P25'];
        $response[$i][25] = $row['P26'];
        $response[$i][26] = $row['P27'];
        $response[$i][27] = $row['P28'];
        $response[$i][28] = $row['P29'];
        $response[$i][29] = $row['P30'];
        $response[$i][30] = $row['P31'];
        $response[$i][31] = $row['P32'];
        $response[$i][32] = $row['P33'];
        $response[$i][33] = $row['P34'];
        $response[$i][34] = $row['P35'];
        $response[$i][35] = $row['P36'];
        $response[$i][36] = $row['P37'];
        $response[$i][37] = $row['P38'];
        $response[$i][38] = $row['P39'];
        $response[$i][39] = $row['P40'];
        $response[$i][40] = $row['P41'];
        $response[$i][41] = $row['P42'];
        $response[$i][42] = $row['P43'];
        $response[$i][43] = $row['P44'];
        $response[$i][44] = $row['P45'];
        $response[$i][45] = $row['P46'];
        $response[$i][46] = $row['P47'];
        $response[$i][47] = $row['P48'];
        $response[$i][48] = $row['P49'];
        $response[$i][49] = $row['P50'];
        $response[$i][50] = $row['P51'];
        $response[$i][51] = $row['P52'];
        $response[$i][52] = $row['P53'];
        $response[$i][53] = $row['P54'];
        $response[$i][54] = $row['P55'];
        $response[$i][55] = $row['P56'];
        $response[$i][56] = $row['P57'];
        $response[$i][57] = $row['P58'];
        $response[$i][58] = $row['P59'];
        $i++;
    }

    for ($c = 0; $c < 59; $c++){
        for ($f = 0; $f < sizeof($data); $f++){
            switch($response[$f][$c]) {
                case 0:
                    $cero++;
                break;
                case 1:
                    $uno++;
                break;
                case 2:
                    $dos++;
                break;
                case 3:
                    $tres++;
                break;
                case 4:
                    $cuatro++;
                break;
                case 5:
                    $cinco++;
                break;
            }
        }
        $rta[$c][0] = $cero;
        $rta[$c][1] = $uno;
        $rta[$c][2] = $dos;
        $rta[$c][3] = $tres;
        $rta[$c][4] = $cuatro;
        $rta[$c][5] = $cinco;
        $cero = 0;
        $uno = 0;
        $dos = 0;
        $tres = 0;
        $cuatro = 0;
        $cinco = 0;
    }

    /*for ($f = 0; $f < sizeof($data); $f++){
        for ($c = 0; $c < 46; $c++){
            echo $response[$f][$c], " - ";
        }
        echo "<br>";
    }*/
    echo "Respuestas: ", "0", " || ", "1", " || ", "2", " || ", "3", " || ", "4", " || ", "5";
    echo "<br>";
    for ($f = 0; $f < sizeof($rta); $f++){
        echo "Pregunta ", ($f+1), ": ";
        for ($c = 0; $c < 6; $c++){
            echo $rta[$f][$c], " - ";
        }
        echo "<br>";
    }
    
    $ruta = "../models/grafica.xlsx";
    $reader = IOFactory::createReader("Xlsx");
    $spreadsheet = $reader->load($ruta);
    $spreadsheet->setActiveSheetIndex(0);
    $sheet = $spreadsheet->getActiveSheet();

    $df = 0;
    $dc = 0;
    for($f = "2"; $f < "61"; $f++){
        for($c = "B"; $c < "H"; $c++){
            $a = $rta[$df][$dc];
            $sheet->setCellValue($c.$f, $rta[$df][$dc]);
            $dc++;
        }
        $dc = 0;
        $df++;
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="grafica.xlsx"');
    header('Cache-Control: max-age=0');

    $writer = IOFactory::createWriter($spreadsheet, "Xlsx");
    ob_end_clean();
    $writer->save('php://output');

    /*$writer = new Xlsx($spreadsheet);
    $writer->save('grafica administrativos.xlsx');*/



    

    





//}else{
    //echo 'Error';
//}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;