<?php
include '../path.php';
include_once '../../backend/conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$sp = "CALL acabacom_fucla.update_estado_rc()";
$result = $conexion->prepare($sp);
$result->execute();

$consulta = "SELECT ID,PROGRAMA,MODALIDAD,RESOLUCION_RC,VENCIMENTO_RC,
AUTOEVALUCION1,PLAN_MEJORA_1,
SEGUIMIENTO_1,AUTOEVALUCION2,PLAN_MEJORA_2,SEGUIMIENTO_2,
RADICACION_SACES,INICIO_DOC_MAESTRO,DOC_MAESTRO, ESTADO_RC FROM view_semaforo_rc";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);

$color = array("", "53FF00", "FFFF00", "FF0000");
$docActivo = array(0, 0, 0, 0, 0);

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../datatables/datatables.min.css" />
    <link href="../datatables/DataTables-1.10.23/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="../datatables/responsive.bootstrap4.min.css" rel="stylesheet">
    <!--datables estilo bootstrap 4 CSS-->
    <link rel="stylesheet" type="text/css" href="../datatables/DataTables-1.10.23/css/dataTables.bootstrap4.min.css">

</head>

<body id="page-top">

    <div id="wrapper">
        <?php  include_once ("sidebar.php");?>
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <?php  include_once ("nav.php");?>
                <div class="container-fluid">
                    <div class="container caja">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive">
                                    <div class="table-responsive">
                                        <table id="tablaUsuarios"
                                            class="table table-striped table-bordered table-condensed dt-responsive nowrap animate__animated  animate__fadeInDown"
                                            style="width:100%">
                                            <thead class="text-center bg-success text-white">
                                                <tr>
                                                    <th>#</th>
                                                    <th>PROGRAMA</th>
                                                    <th>MODALIDAD</th>
                                                    <th>RESOLUCION_RC</th>
                                                    <th>VENCIMENTO_RC</th>
                                                    <th>AUTOEVALUCION1</th>
                                                    <th>PLAN_MEJORA_1</th>
                                                    <th>SEGUIMIENTO_1</th>
                                                    <th>AUTOEVALUCION2</th>
                                                    <th>PLAN_MEJORA_2</th>
                                                    <th>SEGUIMIENTO_2</th>
                                                    <th>RADICACION_SACES</th>
                                                    <th>INICIO_DOC_MAESTRO</th>
                                                    <th>DOC_MAESTRO</th>
                                                    <th>SUBIR DOCUMENTOS</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($data as $key => $muestra):?>
                                                <tr>
                                                    <td bgcolor="<?php echo $color[$muestra['ESTADO_RC']-1]?>"><b><?php echo $key + 1; ?></b></td>
                                                    <td bgcolor="<?php echo $color[$muestra['ESTADO_RC']-1]?>"><b><?php echo $muestra['PROGRAMA'];?></b></td>
                                                    <td bgcolor="<?php echo $color[$muestra['ESTADO_RC']-1]?>"><b><?php echo $muestra['MODALIDAD'];?></b></td>
                                                    <td><?php echo $muestra['RESOLUCION_RC'];?></td>
                                                    <td><?php echo $muestra['VENCIMENTO_RC'];?></td>
                                                    <td><?php echo $muestra['AUTOEVALUCION1'];?></td>
                                                    <td>
                                                        <?php if (empty($muestra['PLAN_MEJORA_1'])):?>
                                                        <?php  echo "[ Vacio - Sin Archivo ] ". $muestra['PLAN_MEJORA_1'];?>
                                                        <?php else:?>
                                                        <a href="<?php echo BASE_URL .'views/'.$muestra['PLAN_MEJORA_1'];?> "
                                                            download="<?php echo $muestra['PLAN_MEJORA_1'];?>"
                                                            class=" btn btn-success btn-sm  animate__animated  animate__fadeInDown">
                                                            <i class="fas fa-cloud-download-alt"></i> </a>
                                                        <?php endif;?>

                                                    </td>
                                                    <td>
                                                        <?php if (empty($muestra['SEGUIMIENTO_1'])):?>
                                                        <?php  echo "[ Vacio - Sin Archivo ] ". $muestra['SEGUIMIENTO_1'];?>
                                                        <?php else:?>
                                                        <a href="<?php echo BASE_URL .'views/'.$muestra['SEGUIMIENTO_1'];?> "
                                                            download="<?php echo $muestra['SEGUIMIENTO_1'];?>"
                                                            class=" btn btn-success btn-sm  animate__animated  animate__fadeInDown">
                                                            <i class="fas fa-cloud-download-alt"></i> </a>
                                                        <?php endif;?>

                                                    </td>
                                                    <td><?php echo $muestra['AUTOEVALUCION2'];?></td>
                                                    <td>
                                                        <?php if (empty($muestra['PLAN_MEJORA_2'])):?>
                                                        <?php  echo "[ Vacio - Sin Archivo ] ". $muestra['PLAN_MEJORA_2'];?>
                                                        <?php else:?>
                                                        <a href="<?php echo BASE_URL .'views/'.$muestra['PLAN_MEJORA_2'];?> "
                                                            download="<?php echo $muestra['PLAN_MEJORA_2'];?>"
                                                            class=" btn btn-success btn-sm  animate__animated  animate__fadeInDown">
                                                            <i class="fas fa-cloud-download-alt"></i> </a>
                                                        <?php endif;?>

                                                    </td>
                                                    <td>
                                                        <?php if (empty($muestra['SEGUIMIENTO_2'])):?>
                                                        <?php  echo "[ Vacio - Sin Archivo ] ". $muestra['SEGUIMIENTO_2'];?>
                                                        <?php else:?>
                                                        <a href="<?php echo BASE_URL .'views/'.$muestra['SEGUIMIENTO_2'];?> "
                                                            download="<?php echo $muestra['SEGUIMIENTO_2'];?>"
                                                            class=" btn btn-success btn-sm  animate__animated  animate__fadeInDown">
                                                            <i class="fas fa-cloud-download-alt"></i> </a>
                                                        <?php endif;?>

                                                    </td>
                                                    <td><?php echo $muestra['RADICACION_SACES'];?></td>
                                                    <td><?php echo $muestra['INICIO_DOC_MAESTRO'];?></td>
                                                    <td>
                                                        <?php if (empty($muestra['DOC_MAESTRO'])):?>
                                                        <?php  echo "[ Vacio - Sin Archivo ] ". $muestra['DOC_MAESTRO'];?>
                                                        <?php else:?>
                                                        <a href="<?php echo BASE_URL .'views/'.$muestra['DOC_MAESTRO'];?> "
                                                            download="<?php echo $muestra['DOC_MAESTRO'];?>"
                                                            class=" btn btn-success btn-sm  animate__animated  animate__fadeInDown">
                                                            <i class="fas fa-cloud-download-alt"></i> </a>
                                                        <?php endif;?>

                                                    </td>

                                                    <?php
                                                        $docActivo[0] = (empty($muestra['PLAN_MEJORA_1'])) ? 0 : 1;
                                                        $docActivo[1] = (empty($muestra['SEGUIMIENTO_1'])) ? 0 : 1;
                                                        $docActivo[2] = (empty($muestra['PLAN_MEJORA_2'])) ? 0 : 1;
                                                        $docActivo[3] = (empty($muestra['SEGUIMIENTO_2'])) ? 0 : 1;
                                                        $docActivo[4] = (empty($muestra['DOC_MAESTRO'])) ? 0 : 1;
                                                        $enviar_url = serialize($docActivo);
                                                        $enviar_url = urlencode($enviar_url);
                                                    ?>

                                                    <td>
                                                        <a href="subirSema.php?id=<?php echo $muestra['ID'];?>&docActivo=<?php echo $enviar_url;?>"
                                                            class="btn btn-info btn-sm">
                                                            <i class="fas fa-cloud-upload-alt "></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach;?>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                </div>
                <?php  include_once ("footer.php");?>
            </div>

        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">¿Listo para salir?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Seleccione <strong>"Cerrar sesión"</strong> a continuación si está listo para
                    finalizar su sesión actual.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-primary" href="<?php echo BASE_URLB;?>models/logout.php">Cerrar Sesion</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->

    <script src="https://cdn.jsdelivr.net/npm/vue@2.x/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.js"></script>
    <script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script type="text/javascript" src="../datatables/datatables.min.js"></script>
    <script src="../datatables/responsive.bootstrap4.min.js"></script>
    <script src="../datatables/dataTables.responsive.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        var user_id, opcion;
        opcion = 4;

        tablaUsuarios = $('#tablaUsuarios').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros",
                "zeroRecords": "No se encontraron resultados",
                "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sSearch": "Buscar:",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast": "Último",
                    "sNext": "Siguiente",
                    "sPrevious": "Anterior"
                },
                "sProcessing": "Cargando...",
            },
            responsive: true


        });
    });
    </script>
</body>

</html>