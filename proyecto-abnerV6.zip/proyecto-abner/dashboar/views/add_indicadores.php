<?php
include '../path.php';
include "../../backend/conexion.php";
$objeto = new Conexion();
$conexion = $objeto->Conectar();

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">


</head>

<body id="page-top">

    <div id="wrapper">
        <?php  include_once ("sidebar.php");?>
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <?php  include_once ("nav.php");?>
                <div class="container-fluid">
                    <div class="container caja">
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <h5 class="card-header h5 bg-info text-light">Indicadores</h5>
                                    <div class="card-body">
                                        <h5 class="card-title">Consultar Indicadores</h5>
                                        <p class="card-text font-italic">Es de mayor importacia que sus datos sean
                                            correctos una vez
                                            ingresado al sistemas <strong> no seran modificado</strong>, tocaria
                                            remitirlo al area de
                                            soporte. </p>

                                        <form id="formUsuarios" method="POST" action="actualizar_indicadores.php">
                                            <div class="row">
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-group">
                                                        <label for="condiciones"
                                                            class="col-form-label">Condiciones</label>
                                                        <select class="custom-select form-control" id="condiciones"
                                                            name="condiciones" required>
                                                            <!-- cargar con js -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-group">
                                                        <label for="" class="col-form-label">Aspectos</label>
                                                        <select class="custom-select form-control" id="aspectos"
                                                            name="aspectos" required>
                                                            <!-- cargar con js -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-group">
                                                        <label for="" class="col-form-label">Indicadores</label>
                                                        <select class="custom-select form-control" id="indicadores"
                                                            name="indicadores" required>
                                                            <!-- cargar con js -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-group">
                                                        <label for="modalidad" class="col-form-label">Modalidad</label>
                                                        <select class="custom-select form-control" id="modalidades"
                                                            name="modalidades" required>
                                                            <!-- cargar con js -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-group">
                                                        <label for="programa" class="col-form-label">Programa</label>
                                                        <select class="custom-select form-control" id="programas"
                                                            name="programas" required>
                                                            <!-- cargar con js -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <div class="form-group">
                                                        <label for="" class="col-form-label">Fecha inicio</label>
                                                        <input type="date" class="form-control" id="fecha_ini"
                                                            name="fecha_ini" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="submit" id="btnGuardar" name="btnGuardar"
                                                class="btn btn-dark">Buscar </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                </div>
                <?php  include_once ("footer.php");?>
            </div>

        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">¿Listo para salir?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Seleccione <strong>"Cerrar sesión"</strong> a continuación si está listo para
                    finalizar su sesión actual.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-primary" href="<?php echo BASE_URLB;?>models/logout.php">Cerrar Sesion</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>
    <script src="../js/select.js"></script>

    <!-- Page level plugins -->

    <script src="https://cdn.jsdelivr.net/npm/vue@2.x/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.js"></script>
    <script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

</body>

</html>