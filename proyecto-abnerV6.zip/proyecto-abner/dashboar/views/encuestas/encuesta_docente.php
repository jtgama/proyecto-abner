<?php
include '../../../dashboar/path.php';
include "../../../backend/conexion.php";
$objeto = new Conexion();
$conexion = $objeto->Conectar();
$query = "SELECT id as id, concat_ws(' - ', PROGRAMA, MODALIDAD) as programa FROM view_encuestas where estado = 'ACTIVO'";
$consulta = $conexion->prepare($query);
$consulta->setFetchMode(PDO::FETCH_ASSOC);
$consulta->execute();
$result = $consulta->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../../../dashboar/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/f…
[10:05 p. m., 25/8/2021] garridos: <!doctype html>
<html lang=" es">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

        <title>navbar con vue router</title>
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
        <script src="https://kit.fontawesome.com/4d248b1a6c.js" crossorigin="anonymous"></script>
        <link href="../../../dashboar/css/sb-admin-2.min.css" rel="stylesheet">
        <style>
        .contenedor {

            height: 100%;
            width: 100%;
            display: flex;
            position: fixed;
            align-items: center;
            justify-content: center;

        }



        .contacto {
            background-color: #304ffe;
        }

        .portafolio {
            background-color: #474747;
        }
        </style>

    </head>

<body>

    <div class="container pt-md-5 m-lg-5">

        <div class="row">

            <div class="col-xl-12">
                <div class="card ">
                    <h5 class="card-header h5 bg-warning text-light"> <i class="fas fa-clipboard-list"></i> ENCUESTA
                        DOCENTE</h5>
                    <div class="card-body">
                        <h6 class="card-title text-center fw-bolder ">PROCESO DE AUTOEVALUACIÓN PROGRAMA CON FINES DE
                            RENOVACIÓN DE REGISTRO CALIFICADO </h6>
                        <p class="card-text font-italic text-justify"><strong> Apreciado Docente:</strong> Se ha
                            diseñado la presente encuesta, con el propósito de recopilar información sobre la percepción
                            que tienen nuestros docentes del programa de <strong>XXXXXXXXXXXXX </strong>sobre el
                            funcionamiento, la calidad de sus procesos y el cumplimiento del Proyecto Educativo (PEU).
                            En este instrumento usted encontrará una serie de ítems que podrá calificar, dependiendo de
                            su nivel de percepción con respecto a cada uno de ellos, en una escala de conformidad de 0 a
                            5 así: </p>
                        <div class="d-flex justify-content-center">
                            <table class="table table-bordered animate_animated  animate_fadeInDown"
                                style="width:100px;">
                                <thead class="bg-dark text-white">
                                    <tr>
                                        <th>Grado de cumplimiento</th>
                                        <th>Conocimiento</th>
                                        <th>Rango</th>
                                    </tr>
                                </thead>
                                <tbody class="text-align: justify">
                                    <tr>

                                        <td>Plenamente</td>
                                        <td>Totalmente</td>
                                        <td>5</td>

                                    </tr>
                                    <tr>

                                        <td>En buen grado </td>
                                        <td>Buen grado</td>
                                        <td>4</td>
                                    </tr>
                                    <tr>

                                        <td>Aceptablemente </td>
                                        <td>Mediano grado</td>
                                        <td>3</td>
                                    </tr>
                                    <tr>

                                        <td>En bajo grado</td>
                                        <td>Poco</td>
                                        <td>2</td>
                                    </tr>
                                    <tr>

                                        <td>No se cumple</td>
                                        <td>Nada</td>
                                        <td>1</td>
                                    </tr>
                                    <tr>

                                        <td>No sabe</td>
                                        <td>No sabe</td>
                                        <td>0</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <p class="card-text font-italic text-justify">En el caso que alguno de los
                            ítems presentados sea de su total desconocimiento o
                            en caso de no contar con información para emitir un
                            juicio justo sobre la afirmación, podrá elegir la opción cero (0)
                            <strong>“No sabe o desconoce totalmente del tema referenciado”.</strong> <br><br>
                            De antemano se agradece su tiempo y colaboración en el diligenciamiento de este instrumento.

                        </p>
                        <form id="formUsuarios" method="POST" action="../../../backend/models/add_encuesta_docente.php">

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="municip" class="col-form-label">Programa:</label>
                                        <select class="custom-select form-control text-uppercase" id="idPrograma"
                                            name="idPrograma" required>
                                            <option value="">Seleccione</option>
                                            <?php
                                        foreach ($result as $valores):
                                            echo '<option value="'.$valores['id'].'">'.$valores['programa'].'</option>';
                                            endforeach;
                                        ?>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class="d-flex justify-content-center ">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> * MECANISMOS DE SELECCIÓN Y
                                            EVALUACIÓN DOCENTES Y ESTUDIANTES *</strong> </p>
                                    <table class="table table-bordered animate_animated  animate_fadeInDown"
                                        style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>
                                                    <p>1. ¿Considera usted que el proceso de admisión de los estudiantes
                                                        en
                                                        la Uniclaretiana es claro y transparente?</p>
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="0" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="1" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="2" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="3" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="4" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="5" />
                                                </td>

                                            </tr>
                                            <tr>

                                                <td>2. ¿Considera usted que los mecanismos de selección de Uniclaretiana
                                                    son adecuados?
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="0" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="1" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="2" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="3" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="4" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>

                                                <td>3. ¿En la Uniclaretiana existen criterios de ingreso y se aplican a
                                                    todos los aspirantes? </td>
                                                <td><input id="p3" name="p3" type="radio" value="0" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="1" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="2" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="3" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="4" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="5" />
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> Considera usted que el
                                            Sistema de Registro Académico se realiza de manera oportuna, respecto a los
                                            siguientes procesos: </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>4. Admisiones </td>
                                                <td><input id="p4" name="p4" type="radio" value="0" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="1" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="2" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="3" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="4" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>5. Registro de notas
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="0" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="1" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="2" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="3" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="4" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>6. Elaboración de horarios y asignación de aulas</td>
                                                <td><input id="p6" name="p6" type="radio" value="0" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="1" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="2" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="3" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="4" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p>7. Reportes estadísticos (calificaciones, faltas de asistencia,
                                                        entre otros)</p>
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="0" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="1" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="2" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="3" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="4" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="5" />
                                                </td>

                                            </tr>
                                            <tr>

                                                <td>8. Proceso de matrícula</td>
                                                <td><input id="p8" name="p8" type="radio" value="0" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="1" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="2" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="3" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="4" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="5" />
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">

                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>9. ¿El reglamento estudiantil y académico de Uniclaretiana es
                                                    pertinente y se aplica adecuadamente? </td>
                                                <td><input id="p9" name="p9" type="radio" value="0" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="1" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="2" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="3" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="4" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="5" />
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> Mecanismos de selección y
                                            evaluación docentes</strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>
                                                    <p>10. ¿Considera que los profesores vinculados al programa cumplen
                                                        a
                                                        satisfacción sus funciones?</p>
                                                </td>
                                                <td><input id="p10" name="p10" type="radio" value="0" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="1" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="2" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="3" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="4" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>11. ¿Considera usted que los mecanismos que se tienen para
                                                        evaluar a
                                                        los profesores, así como los aspectos que se tienen en cuenta,
                                                        permiten conocer cómo es el desempeño de cada profesor?</p>
                                                </td>
                                                <td><input id="p11" name="p11" type="radio" value="0" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="1" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="2" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="3" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="4" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>12. ¿Considera usted que los resultados de la evaluación de los
                                                    profesores realizada por los estudiantes se tienen en cuenta para el
                                                    mejoramiento de los procesos académicos?
                                                </td>
                                                <td><input id="p12" name="p12" type="radio" value="0" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="1" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="2" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="3" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="4" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>13. ¿Considera usted que los criterios y procedimientos de
                                                    vinculación
                                                    de los profesores son coherentes con las necesidades de la
                                                    institución?
                                                </td>
                                                <td><input id="p13" name="p13" type="radio" value="0" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="1" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="2" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="3" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="4" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>14. ¿la contratación de los docentes del programa se efectúa
                                                        considerando su formación académica y experiencia profesional?
                                                    </p>
                                                </td>
                                                <td><input id="p14" name="p14" type="radio" value="0" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="1" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="2" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="3" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="4" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>15. ¿El programa cuenta con un número suficiente de docentes para
                                                    desarrollar las actividades de docencia, investigación y extensión?
                                                </td>
                                                <td><input id="p15" name="p15" type="radio" value="0" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="1" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="2" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="3" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="4" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>16. ¿La institución ofrece al docente actividades académicas,
                                                    investigativas y culturales, que contribuyen a su cualificación?
                                                </td>
                                                <td><input id="p16" name="p16" type="radio" value="0" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="1" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="2" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="3" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="4" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>17. ¿El estatuto docente es pertinente y se aplica conforme a lo
                                                    establecido?
                                                </td>
                                                <td><input id="p17" name="p17" type="radio" value="0" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="1" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="2" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="3" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="4" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>18. ¿La evaluación a los docentes, se realizan con criterios de
                                                    equidad, transparencia y eficacia? </td>
                                                <td><input id="p18" name="p18" type="radio" value="0" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="1" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="2" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="3" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="4" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>19. ¿A partir de los resultados de la evaluación al desempeño
                                                    docente,
                                                    se establecen acciones de mejora para el docente y el programa?</td>
                                                <td><input id="p19" name="p19" type="radio" value="0" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="1" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="2" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="3" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="4" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> ESTRUCTURA ADMINISTRATIVA Y
                                            ACADÉMICA </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS</th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>20. ¿Existen ambientes propicios para la discusión crítica sobre
                                                    ciencia, tecnología, valores, sociedad y estado?</td>
                                                <td><input id="p20" name="p20" type="radio" value="0" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="1" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="2" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="3" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="4" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>21. ¿La Uniclaretiana cuenta con tecnologías de información que
                                                        permiten realizar procesos académicos adecuadamente?</p>
                                                </td>
                                                <td><input id="p21" name="p21" type="radio" value="0" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="1" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="2" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="3" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="4" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>22. ¿La Uniclaretiana posee políticas que garantice la actualización
                                                    de los planes de formación?</td>
                                                <td><input id="p22" name="p22" type="radio" value="0" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="1" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="2" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="3" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="4" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>23. ¿Usted como docente ha participado en la actualización de los
                                                        planes de formación?</p>
                                                </td>
                                                <td><input id="p23" name="p23" type="radio" value="0" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="1" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="2" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="3" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="4" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>24. ¿Las medidas establecidas en el código de buen gobierno se
                                                    cumplen a cabalidad?</td>
                                                <td><input id="p24" name="p24" type="radio" value="0" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="1" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="2" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="3" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="4" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>25. ¿La Uniclaretiana cuenta con una estructura organizacional
                                                        suficiente para atender y satisfacer el funcionamiento de la
                                                        institución?</p>
                                                </td>
                                                <td><input id="p25" name="p25" type="radio" value="0" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="1" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="2" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="3" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="4" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>26. ¿En Uniclaretiana los responsables de la alta dirección de la
                                                    Institución se desempeñan demostrando liderazgo, integridad e
                                                    idoneidad? </td>
                                                <td><input id="p26" name="p26" type="radio" value="0" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="1" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="2" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="3" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="4" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>27. ¿Los sistemas de información de Uniclaretiana permiten conocer
                                                    los logros en la gestión de la Universidad?</td>
                                                <td><input id="p27" name="p27" type="radio" value="0" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="1" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="2" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="3" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="4" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>28. ¿Los programas académicos desarrollan actividades formativas que
                                                    favorecen el desarrollo de competencias investigativas necesarias
                                                    para un profesional?</td>
                                                <td><input id="p28" name="p28" type="radio" value="0" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="1" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="2" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="3" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="4" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>29. ¿Los proyectos y actividades que desarrollan los Grupos y
                                                    Semilleros de investigación contribuyen a mejorar la calidad de los
                                                    programas académicos?
                                                </td>
                                                <td><input id="p29" name="p29" type="radio" value="0" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="1" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="2" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="3" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="4" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>30. ¿La producción académica e investigativa de los docentes tiene
                                                    reconocimiento en el medio académico, empresarial y social?</td>
                                                <td><input id="p30" name="p30" type="radio" value="0" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="1" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="2" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="3" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="4" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>31. ¿Los proyectos de investigación que se realizan en la
                                                    institución atienden las necesidades del entorno empresarial y
                                                    social?
                                                </td>
                                                <td><input id="p31" name="p31" type="radio" value="0" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="1" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="2" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="3" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="4" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong>CULTURA DE LA
                                            AUTOEVALUACIÓN</strong>
                                    </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>32. ¿En la Institución se adelantan procesos participativos de
                                                    autoevaluación tanto institucionales como de programas académicos?
                                                </td>
                                                <td><input id="p32" name="p32" type="radio" value="0" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="1" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="2" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="3" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="4" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>33. ¿La Institución implementa e incorpora en su Plan de Desarrollo
                                                    Institucional, las propuestas de mejoramiento que surgen como
                                                    resultado de los procesos de autoevaluación?</td>
                                                <td><input id="p33" name="p33" type="radio" value="0" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="1" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="2" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="3" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="4" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> MODELO DE BIENESTAR </strong>
                                    </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>34. ¿Los programas de bienestar institucional promueven el
                                                    desarrollo de la personalidad y la convivencia pacífica en la
                                                    comunidad universitaria?
                                                </td>
                                                <td><input id="p34" name="p34" type="radio" value="0" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="1" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="2" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="3" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="4" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>35. ¿Bienestar institucional presta servicios con criterios de
                                                    calidad, efectividad y transparencia?
                                                </td>
                                                <td><input id="p35" name="p35" type="radio" value="0" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="1" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="2" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="3" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="4" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>36. ¿Las actividades de bienestar contribuyen a la permanencia y
                                                    graduación de los estudiantes?
                                                </td>
                                                <td><input id="p36" name="p36" type="radio" value="0" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="1" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="2" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="3" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="4" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>37. ¿La institución interviene en los procesos de formación con un
                                                    enfoque diferencial y de género?
                                                </td>
                                                <td><input id="p37" name="p37" type="radio" value="0" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="1" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="2" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="3" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="4" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>38. ¿Los espacios deportivos, culturales y sociales de Bienestar
                                                    Institucional posibilitan el desarrollo de sus programas y
                                                    actividades?
                                                </td>
                                                <td><input id="p38" name="p38" type="radio" value="0" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="1" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="2" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="3" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="4" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> Analice los siguientes
                                            enunciados y califique cada uno de ellos: </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>39. La contribución de los programas y servicios de bienestar
                                                    institucional a su formación integral.
                                                </td>
                                                <td><input id="p39" name="p39" type="radio" value="0" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="1" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="2" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="3" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="4" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>40. El desarrollo de los programas y servicios de bienestar
                                                    institucional según las necesidades de la comunidad académica.
                                                </td>
                                                <td><input id="p40" name="p40" type="radio" value="0" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="1" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="2" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="3" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="4" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>41. Las políticas y estrategias de bienestar institucional.
                                                </td>
                                                <td><input id="p41" name="p41" type="radio" value="0" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="1" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="2" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="3" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="4" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>42. El clima organizacional de la Institución.
                                                </td>
                                                <td><input id="p42" name="p42" type="radio" value="0" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="1" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="2" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="3" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="4" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>43. Los mecanismos de financiación de la matrícula.
                                                </td>
                                                <td><input id="p43" name="p43" type="radio" value="0" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="1" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="2" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="3" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="4" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>44. El sistema de becas a estudiantes que ofrece la Institución.
                                                </td>
                                                <td><input id="p44" name="p44" type="radio" value="0" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="1" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="2" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="3" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="4" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>45. El apoyo de los servicios de bienestar sobre la calidad de la
                                                    docencia.
                                                </td>
                                                <td><input id="p45" name="p45" type="radio" value="0" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="1" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="2" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="3" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="4" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>46. El apoyo de los servicios de bienestar sobre la calidad de la
                                                    investigación.
                                                </td>
                                                <td><input id="p46" name="p46" type="radio" value="0" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="1" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="2" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="3" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="4" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>47. El apoyo de los servicios de bienestar sobre la calidad de la
                                                    extensión.
                                                </td>
                                                <td><input id="p47" name="p47" type="radio" value="0" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="1" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="2" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="3" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="4" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>48. El apoyo de los servicios de bienestar sobre la calidad de la
                                                    internacionalización.
                                                </td>
                                                <td><input id="p48" name="p48" type="radio" value="0" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="1" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="2" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="3" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="4" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> Califique la adecuación de
                                            los espacios, equipos y materiales para el desarrollo de las actividades y
                                            servicios de bienestar: </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>49. Recreación
                                                </td>
                                                <td><input id="p49" name="p49" type="radio" value="0" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="1" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="2" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="3" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="4" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>50. Cultura
                                                </td>
                                                <td><input id="p50" name="p50" type="radio" value="0" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="1" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="2" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="3" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="4" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>51. Deporte
                                                </td>
                                                <td><input id="p51" name="p51" type="radio" value="0" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="1" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="2" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="3" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="4" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>52. Salud
                                                </td>
                                                <td><input id="p52" name="p52" type="radio" value="0" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="1" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="2" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="3" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="4" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong>Califique la suficiencia de
                                            los espacios, equipos y materiales para el desarrollo de las actividades y
                                            servicios de bienestar</strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>53. Recreación
                                                </td>
                                                <td><input id="p53" name="p53" type="radio" value="0" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="1" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="2" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="3" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="4" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>54. Cultura
                                                </td>
                                                <td><input id="p54" name="p54" type="radio" value="0" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="1" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="2" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="3" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="4" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>55. Deporte
                                                </td>
                                                <td><input id="p55" name="p55" type="radio" value="0" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="1" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="2" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="3" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="4" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>56. Salud
                                                </td>
                                                <td><input id="p56" name="p56" type="radio" value="0" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="1" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="2" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="3" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="4" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">

                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>57. ¿Considera usted que el manejo dado por el personal de bienestar
                                                    para la divulgación de sus actividades y servicios son los
                                                    adecuados?
                                                </td>
                                                <td><input id="p57" name="p57" type="radio" value="0" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="1" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="2" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="3" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="4" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>58. ¿Considera usted que el personal para atender las actividades y
                                                    servicios de bienestar son suficientes?
                                                </td>
                                                <td><input id="p58" name="p58" type="radio" value="0" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="1" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="2" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="3" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="4" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>59. ¿Considera usted que el personal que atiende las actividades y
                                                    servicios de bienestar presta sus servicios con calidad?
                                                </td>
                                                <td><input id="p59" name="p59" type="radio" value="0" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="1" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="2" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="3" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="4" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>60. ¿Considera usted que las actividades y servicios de bienestar
                                                    aportan a su formación integral?
                                                </td>
                                                <td><input id="p60" name="p60" type="radio" value="0" /></td>
                                                <td><input id="p60" name="p60" type="radio" value="1" /></td>
                                                <td><input id="p60" name="p60" type="radio" value="2" /></td>
                                                <td><input id="p60" name="p60" type="radio" value="3" /></td>
                                                <td><input id="p60" name="p60" type="radio" value="4" /></td>
                                                <td><input id="p60" name="p60" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> RECURSOS SUFICIENTES PARA
                                            GARANTIZAR EL CUMPLIMIENTO DE LAS METAS </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>61. ¿Considera usted que el material bibliográfico disponible en la
                                                    biblioteca es pertinente para el desarrollo de las tareas académicas
                                                    en las diferentes áreas del conocimiento?
                                                </td>
                                                <td><input id="p61" name="p61" type="radio" value="0" /></td>
                                                <td><input id="p61" name="p61" type="radio" value="1" /></td>
                                                <td><input id="p61" name="p61" type="radio" value="2" /></td>
                                                <td><input id="p61" name="p61" type="radio" value="3" /></td>
                                                <td><input id="p61" name="p61" type="radio" value="4" /></td>
                                                <td><input id="p61" name="p61" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>62. ¿Considera usted que el material bibliográfico disponible en la
                                                    biblioteca atiende la demanda estudiantil?
                                                </td>
                                                <td><input id="p62" name="p62" type="radio" value="0" /></td>
                                                <td><input id="p62" name="p62" type="radio" value="1" /></td>
                                                <td><input id="p62" name="p62" type="radio" value="2" /></td>
                                                <td><input id="p62" name="p62" type="radio" value="3" /></td>
                                                <td><input id="p62" name="p62" type="radio" value="4" /></td>
                                                <td><input id="p62" name="p62" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>63. ¿Considera usted que el material bibliográfico disponible en la
                                                    biblioteca física y virtual se encuentra actualizado en función de
                                                    la innovación científica y tecnológica en el contexto mundial?
                                                </td>
                                                <td><input id="p63" name="p63" type="radio" value="0" /></td>
                                                <td><input id="p63" name="p63" type="radio" value="1" /></td>
                                                <td><input id="p63" name="p63" type="radio" value="2" /></td>
                                                <td><input id="p63" name="p63" type="radio" value="3" /></td>
                                                <td><input id="p63" name="p63" type="radio" value="4" /></td>
                                                <td><input id="p63" name="p63" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>64. ¿Considera usted que los sistemas de consulta de la biblioteca son ágiles y de fácil utilización?
                                                </td>
                                                <td><input id="p64" name="p64" type="radio" value="0" /></td>
                                                <td><input id="p64" name="p64" type="radio" value="1" /></td>
                                                <td><input id="p64" name="p64" type="radio" value="2" /></td>
                                                <td><input id="p64" name="p64" type="radio" value="3" /></td>
                                                <td><input id="p64" name="p64" type="radio" value="4" /></td>
                                                <td><input id="p64" name="p64" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>65. ¿Considera usted que los equipos de cómputo (Aulas de informática) que cuenta la Uniclaretiana para el desarrollo de las actividades académicas están actualizados?
                                                </td>
                                                <td><input id="p65" name="p65" type="radio" value="0" /></td>
                                                <td><input id="p65" name="p65" type="radio" value="1" /></td>
                                                <td><input id="p65" name="p65" type="radio" value="2" /></td>
                                                <td><input id="p65" name="p65" type="radio" value="3" /></td>
                                                <td><input id="p65" name="p65" type="radio" value="4" /></td>
                                                <td><input id="p65" name="p65" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>66. ¿Considera usted que los equipos de cómputo (Sala de Internet biblioteca) que cuenta la Uniclaretiana para el desarrollo de las actividades académicas están actualizados?
                                                </td>
                                                <td><input id="p66" name="p66" type="radio" value="0" /></td>
                                                <td><input id="p66" name="p66" type="radio" value="1" /></td>
                                                <td><input id="p66" name="p66" type="radio" value="2" /></td>
                                                <td><input id="p66" name="p66" type="radio" value="3" /></td>
                                                <td><input id="p66" name="p66" type="radio" value="4" /></td>
                                                <td><input id="p66" name="p66" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>67. ¿Considera usted que los equipos audiovisuales con los que cuenta la Universidad son suficientes?
                                                </td>
                                                <td><input id="p67" name="p67" type="radio" value="0" /></td>
                                                <td><input id="p67" name="p67" type="radio" value="1" /></td>
                                                <td><input id="p67" name="p67" type="radio" value="2" /></td>
                                                <td><input id="p67" name="p67" type="radio" value="3" /></td>
                                                <td><input id="p67" name="p67" type="radio" value="4" /></td>
                                                <td><input id="p67" name="p67" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>68. ¿Los sistemas de información institucional son eficientes?
                                                </td>
                                                <td><input id="p68" name="p68" type="radio" value="0" /></td>
                                                <td><input id="p68" name="p68" type="radio" value="1" /></td>
                                                <td><input id="p68" name="p68" type="radio" value="2" /></td>
                                                <td><input id="p68" name="p68" type="radio" value="3" /></td>
                                                <td><input id="p68" name="p68" type="radio" value="4" /></td>
                                                <td><input id="p68" name="p68" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>69. ¿Los mecanismos de comunicación institucional son eficientes?
                                                </td>
                                                <td><input id="p69" name="p69" type="radio" value="0" /></td>
                                                <td><input id="p69" name="p69" type="radio" value="1" /></td>
                                                <td><input id="p69" name="p69" type="radio" value="2" /></td>
                                                <td><input id="p69" name="p69" type="radio" value="3" /></td>
                                                <td><input id="p69" name="p69" type="radio" value="4" /></td>
                                                <td><input id="p69" name="p69" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>70. ¿La tecnología para garantizar una adecuada conectividad a los miembros de la comunidad académica es eficiente?
                                                </td>
                                                <td><input id="p70" name="p70" type="radio" value="0" /></td>
                                                <td><input id="p70" name="p70" type="radio" value="1" /></td>
                                                <td><input id="p70" name="p70" type="radio" value="2" /></td>
                                                <td><input id="p70" name="p70" type="radio" value="3" /></td>
                                                <td><input id="p70" name="p70" type="radio" value="4" /></td>
                                                <td><input id="p70" name="p70" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>71. ¿Los laboratorios para desempeñar las tareas académicas de la institución son de calidad?
                                                </td>
                                                <td><input id="p71" name="p71" type="radio" value="0" /></td>
                                                <td><input id="p71" name="p71" type="radio" value="1" /></td>
                                                <td><input id="p71" name="p71" type="radio" value="2" /></td>
                                                <td><input id="p71" name="p71" type="radio" value="3" /></td>
                                                <td><input id="p71" name="p71" type="radio" value="4" /></td>
                                                <td><input id="p71" name="p71" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>72. ¿Los laboratorios para desempeñar las tareas académicas de la institución son pertinentes?
                                                </td>
                                                <td><input id="p72" name="p72" type="radio" value="0" /></td>
                                                <td><input id="p72" name="p72" type="radio" value="1" /></td>
                                                <td><input id="p72" name="p72" type="radio" value="2" /></td>
                                                <td><input id="p72" name="p72" type="radio" value="3" /></td>
                                                <td><input id="p72" name="p72" type="radio" value="4" /></td>
                                                <td><input id="p72" name="p72" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong>Califique, en términos generales, las características de la planta física de la Universidad:</strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>73. Suficiencia de espacios
                                                </td>
                                                <td><input id="p73" name="p73" type="radio" value="0" /></td>
                                                <td><input id="p73" name="p73" type="radio" value="1" /></td>
                                                <td><input id="p73" name="p73" type="radio" value="2" /></td>
                                                <td><input id="p73" name="p73" type="radio" value="3" /></td>
                                                <td><input id="p73" name="p73" type="radio" value="4" /></td>
                                                <td><input id="p73" name="p73" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>74. Distribución de espacios
                                                </td>
                                                <td><input id="p74" name="p74" type="radio" value="0" /></td>
                                                <td><input id="p74" name="p74" type="radio" value="1" /></td>
                                                <td><input id="p74" name="p74" type="radio" value="2" /></td>
                                                <td><input id="p74" name="p74" type="radio" value="3" /></td>
                                                <td><input id="p74" name="p74" type="radio" value="4" /></td>
                                                <td><input id="p74" name="p74" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>75. Facilidad de acceso
                                                </td>
                                                <td><input id="p75" name="p75" type="radio" value="0" /></td>
                                                <td><input id="p75" name="p75" type="radio" value="1" /></td>
                                                <td><input id="p75" name="p75" type="radio" value="2" /></td>
                                                <td><input id="p75" name="p75" type="radio" value="3" /></td>
                                                <td><input id="p75" name="p75" type="radio" value="4" /></td>
                                                <td><input id="p75" name="p75" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>76. Iluminación
                                                </td>
                                                <td><input id="p76" name="p76" type="radio" value="0" /></td>
                                                <td><input id="p76" name="p76" type="radio" value="1" /></td>
                                                <td><input id="p76" name="p76" type="radio" value="2" /></td>
                                                <td><input id="p76" name="p76" type="radio" value="3" /></td>
                                                <td><input id="p76" name="p76" type="radio" value="4" /></td>
                                                <td><input id="p76" name="p76" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>77. Ventilación
                                                </td>
                                                <td><input id="p77" name="p77" type="radio" value="0" /></td>
                                                <td><input id="p77" name="p77" type="radio" value="1" /></td>
                                                <td><input id="p77" name="p77" type="radio" value="2" /></td>
                                                <td><input id="p77" name="p77" type="radio" value="3" /></td>
                                                <td><input id="p77" name="p77" type="radio" value="4" /></td>
                                                <td><input id="p77" name="p77" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>78. Limpieza
                                                </td>
                                                <td><input id="p78" name="p78" type="radio" value="0" /></td>
                                                <td><input id="p78" name="p78" type="radio" value="1" /></td>
                                                <td><input id="p78" name="p78" type="radio" value="2" /></td>
                                                <td><input id="p78" name="p78" type="radio" value="3" /></td>
                                                <td><input id="p78" name="p78" type="radio" value="4" /></td>
                                                <td><input id="p78" name="p78" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>79. Condiciones de seguridad
                                                </td>
                                                <td><input id="p79" name="p79" type="radio" value="0" /></td>
                                                <td><input id="p79" name="p79" type="radio" value="1" /></td>
                                                <td><input id="p79" name="p79" type="radio" value="2" /></td>
                                                <td><input id="p79" name="p79" type="radio" value="3" /></td>
                                                <td><input id="p79" name="p79" type="radio" value="4" /></td>
                                                <td><input id="p79" name="p79" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                            <button type="submit" id="btnGuardar" name="btnGuardar" class="btn btn-dark">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/vue@2.x/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.js"></script>
    <script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
    <script src="../../../dashboar/vendor/jquery/jquery.min.js"></script>
    <script src="../proyecto_abner/proyecto-abner/dashboar/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../../../dashboar/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../../../dashboar/js/sb-admin-2.min.js"></script>

</body>

</html>