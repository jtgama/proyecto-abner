<?php
include '../../../dashboar/path.php';
include "../../../backend/conexion.php";
$objeto = new Conexion();
$conexion = $objeto->Conectar();
$query = "SELECT id as id, concat_ws(' - ', PROGRAMA, MODALIDAD) as programa FROM view_encuestas where estado = 'ACTIVO'";
$consulta = $conexion->prepare($query);
$consulta->setFetchMode(PDO::FETCH_ASSOC);
$consulta->execute();
$result = $consulta->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../../../dashboar/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/f…
[10:05 p. m., 25/8/2021] garridos: <!doctype html>
<html lang=" es">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

        <title>navbar con vue router</title>
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
        <script src="https://kit.fontawesome.com/4d248b1a6c.js" crossorigin="anonymous"></script>
        <link href="../../../dashboar/css/sb-admin-2.min.css" rel="stylesheet">
        <style>
        .contenedor {

            height: 100%;
            width: 100%;
            display: flex;
            position: fixed;
            align-items: center;
            justify-content: center;

        }



        .contacto {
            background-color: #304ffe;
        }

        .portafolio {
            background-color: #474747;
        }
        </style>

    </head>

<body>

    <div class="container pt-md-5 m-lg-5">

        <div class="row">

            <div class="col-xl-12">
                <div class="card ">
                    <h5 class="card-header h5 bg-warning text-light"> <i class="fas fa-clipboard-list"></i> ENCUESTA
                        ADMINISTRATIVOS</h5>
                    <div class="card-body">
                        <h6 class="card-title text-center fw-bolder ">ENCUESTA PROCESO DE AUTOEVALUACIÓN CON FINES DE
                            RENOVACIÓN DE REGISTRO CALIFICADO</h6>
                        <p class="card-text font-italic text-justify"><strong> Apreciado funcionario: Se ha diseñado la
                                presente encuesta con el propósito de conocer la percepción que tiene el personal
                                administrativo de la Institución sobre la calidad de algunos procesos académicos
                                –administrativos del programa XXXXXXXXXXXXXXXXXXX
                                En este instrumento usted encontrará una serie de ítems que podrá calificar, según su
                                nivel de percepción con respecto a cada uno de ellos, en una escala de conformidad de 0
                                a 5 así:
                                : </p>
                        <div class="d-flex justify-content-center">
                            <table class="table table-bordered animate_animated  animate_fadeInDown"
                                style="width:100px;">
                                <thead class="bg-dark text-white">
                                    <tr>
                                        <th>Grado de cumplimiento</th>
                                        <th>Conocimiento</th>
                                        <th>Rango</th>
                                    </tr>
                                </thead>
                                <tbody class="text-align: justify">
                                    <tr>

                                        <td>Plenamente</td>
                                        <td>Totalmente</td>
                                        <td>5</td>

                                    </tr>
                                    <tr>

                                        <td>En buen grado </td>
                                        <td>Buen grado</td>
                                        <td>4</td>
                                    </tr>
                                    <tr>

                                        <td>Aceptablemente </td>
                                        <td>Mediano grado</td>
                                        <td>3</td>
                                    </tr>
                                    <tr>

                                        <td>En bajo grado</td>
                                        <td>Poco</td>
                                        <td>2</td>
                                    </tr>
                                    <tr>

                                        <td>No se cumple</td>
                                        <td>Nada</td>
                                        <td>1</td>
                                    </tr>
                                    <tr>

                                        <td>No sabe</td>
                                        <td>No sabe</td>
                                        <td>0</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <p class="card-text font-italic text-justify">En el caso que alguno de los
                            ítems presentados sea de su total desconocimiento o
                            en caso de no contar con información para emitir un
                            juicio justo sobre la afirmación, podrá elegir la opción cero (0)
                            <strong>“No sabe o desconoce totalmente del tema referenciado”.</strong> <br><br>
                            De antemano se agradece su tiempo y colaboración en el diligenciamiento de este instrumento.

                        </p>
                        <form id="formUsuarios" method="POST"
                            action="../../../backend/models/add_encuesta_administrativos.php">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="municip" class="col-form-label">Programa:</label>
                                        <select class="custom-select form-control text-uppercase" id="idPrograma"
                                            name="idPrograma" required>
                                            <option value="">Seleccione</option>
                                            <?php
                                        foreach ($result as $valores):
                                            echo '<option value="'.$valores['id'].'">'.$valores['programa'].'</option>';
                                            endforeach;
                                        ?>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <p class="card-text font-italic text-justify"><strong> * MECANISMOS DE SELECCIÓN Y
                                    EVALUACIÓN ESTUDIANTES Y DOCENTES *</strong> </p>
                            <div class="d-flex justify-content-center ">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> ESTUDIANTES </strong> </p>
                                    <table class="table table-bordered animate_animated  animate_fadeInDown"
                                        style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>
                                                    <p>1. ¿Los criterios para la admisión y permanencia de los estudiantes
                                                        son transparentes?</p>
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="0" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="1" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="2" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="3" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="4" />
                                                </td>
                                                <td><input id="p1" name="p1" type="radio" value="5" />
                                                </td>

                                            </tr>
                                            <tr>

                                                <td>2. ¿El Proyecto educativo institucional proporciona orientaciones y
                                                    estrategias para el fomento de la formación integral de los
                                                    estudiantes?
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="0" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="1" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="2" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="3" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="4" />
                                                </td>
                                                <td><input id="p2" name="p2" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>

                                                <td>3. ¿Los estudiantes participan activamente de los proyectos y
                                                    actividades de investigación que ofrece la institución?
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="0" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="1" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="2" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="3" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="4" />
                                                </td>
                                                <td><input id="p3" name="p3" type="radio" value="5" />
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> PROFESORES </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>4. ¿Cree usted que son pertinentes las políticas, normas y criterios
                                                    académicos establecidos por la institución para la selección,
                                                    vinculación y permanencia de sus docentes?</td>
                                                <td><input id="p4" name="p4" type="radio" value="0" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="1" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="2" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="3" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="4" />
                                                </td>
                                                <td><input id="p4" name="p4" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>5. ¿Cree usted que se encuentran vigentes las políticas, normas y
                                                    criterios académicos establecidos por la institución para la
                                                    selección, vinculación y permanencia de sus docentes?
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="0" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="1" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="2" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="3" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="4" />
                                                </td>
                                                <td><input id="p5" name="p5" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>6. ¿Existe equidad, transparencia y eficacia en los criterios y
                                                    mecanismos de evaluación de los docentes?</td>
                                                <td><input id="p6" name="p6" type="radio" value="0" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="1" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="2" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="3" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="4" />
                                                </td>
                                                <td><input id="p6" name="p6" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p>7. ¿En los programas se cuenta con un número suficiente de docentes
                                                        para desarrollar las actividades de docencia, investigación y
                                                        extensión?</p>
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="0" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="1" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="2" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="3" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="4" />
                                                </td>
                                                <td><input id="p7" name="p7" type="radio" value="5" />
                                                </td>

                                            </tr>
                                            <tr>

                                                <td>8. ¿Los docentes vinculados a los programas son idóneos profesional y
                                                    académicamente?</td>
                                                <td><input id="p8" name="p8" type="radio" value="0" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="1" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="2" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="3" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="4" />
                                                </td>
                                                <td><input id="p8" name="p8" type="radio" value="5" />
                                                </td>
                                            </tr>
                                            <tr>

                                                <td>9. ¿Los docentes de la institución hacen aportes valiosos para
                                                    desarrollar y revisar los distintos procesos académicos? </td>
                                                <td><input id="p9" name="p9" type="radio" value="0" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="1" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="2" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="3" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="4" />
                                                </td>
                                                <td><input id="p9" name="p9" type="radio" value="5" />
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> ESTRUCTURA ADMINISTRATIVA Y
                                            ACADÉMICA</strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>
                                                    <p>10. ¿El reglamento estudiantil es aplicado con transparencia,
                                                        objetividad y oportunidad?</p>
                                                </td>
                                                <td><input id="p10" name="p10" type="radio" value="0" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="1" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="2" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="3" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="4" /></td>
                                                <td><input id="p10" name="p10" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>11. ¿Los mecanismos y procedimientos de control, seguimiento y
                                                        evaluación de la gestión administrativa en la Institución son
                                                        eficientes?</p>
                                                </td>
                                                <td><input id="p11" name="p11" type="radio" value="0" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="1" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="2" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="3" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="4" /></td>
                                                <td><input id="p11" name="p11" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>12. ¿El modelo organizacional institucional es coherente y se ajusta a
                                                    la modalidad de los programas?
                                                </td>
                                                <td><input id="p12" name="p12" type="radio" value="0" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="1" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="2" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="3" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="4" /></td>
                                                <td><input id="p12" name="p12" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>13. ¿Uniclaretiana se apoya en herramientas informáticas que le permite
                                                    evaluar la ejecución y el desempeño?
                                                </td>
                                                <td><input id="p13" name="p13" type="radio" value="0" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="1" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="2" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="3" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="4" /></td>
                                                <td><input id="p13" name="p13" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>14. ¿La Institución responde a las expectativas de desarrollo de la
                                                        región y de Colombia? </p>
                                                </td>
                                                <td><input id="p14" name="p14" type="radio" value="0" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="1" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="2" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="3" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="4" /></td>
                                                <td><input id="p14" name="p14" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>15. ¿La institución establece relaciones con los diferentes sectores
                                                    sociales y económicos para dar respuestas a sus necesidades? </td>
                                                <td><input id="p15" name="p15" type="radio" value="0" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="1" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="2" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="3" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="4" /></td>
                                                <td><input id="p15" name="p15" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>16. ¿Los programas académicos desarrollan actividades formativas que
                                                    favorecen el fomento de competencias investigativas necesarias para
                                                    un profesional? </td>
                                                <td><input id="p16" name="p16" type="radio" value="0" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="1" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="2" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="3" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="4" /></td>
                                                <td><input id="p16" name="p16" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>17. ¿Los proyectos y actividades que desarrollan los Grupos y
                                                    Semilleros de investigación contribuyen a mejorar la calidad de su
                                                    programa académico?
                                                </td>
                                                <td><input id="p17" name="p17" type="radio" value="0" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="1" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="2" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="3" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="4" /></td>
                                                <td><input id="p17" name="p17" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>18. ¿La producción académica e investigativa de los docentes tiene
                                                    reconocimiento en el medio académico, empresarial y social? </td>
                                                <td><input id="p18" name="p18" type="radio" value="0" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="1" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="2" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="3" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="4" /></td>
                                                <td><input id="p18" name="p18" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>19. ¿Los proyectos de investigación que se realizan en la institución
                                                    atienden las necesidades del entorno empresarial y social?</td>
                                                <td><input id="p19" name="p19" type="radio" value="0" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="1" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="2" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="3" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="4" /></td>
                                                <td><input id="p19" name="p19" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>20. ¿La recepción y respuesta a las Peticiones, Quejas, Reclamos,
                                                    Sugerencias y Denuncias / PQRSD, son efectivas?</td>
                                                <td><input id="p20" name="p20" type="radio" value="0" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="1" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="2" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="3" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="4" /></td>
                                                <td><input id="p20" name="p20" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>21. ¿Los sistemas de información institucionales son eficientes y
                                                        oportunos?</p>
                                                </td>
                                                <td><input id="p21" name="p21" type="radio" value="0" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="1" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="2" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="3" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="4" /></td>
                                                <td><input id="p21" name="p21" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>22. ¿Los procesos de evaluación aplicados a los docentes, directivos y
                                                    personal administrativo, se realizan con criterios de equidad,
                                                    transparencia y eficacia?</td>
                                                <td><input id="p22" name="p22" type="radio" value="0" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="1" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="2" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="3" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="4" /></td>
                                                <td><input id="p22" name="p22" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> CULTURA DE
                                            AUTOEVALUACIÓN</strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS</th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>

                                                <td>
                                                    <p>23. ¿Los sistemas de información utilizados para el desarrollo del
                                                        proceso de autoevaluación son eficientes?</p>
                                                </td>
                                                <td><input id="p23" name="p23" type="radio" value="0" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="1" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="2" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="3" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="4" /></td>
                                                <td><input id="p23" name="p23" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>24. ¿Los sistemas de información utilizados para el desarrollo del
                                                    proceso de autoevaluación son efectivos?</td>
                                                <td><input id="p24" name="p24" type="radio" value="0" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="1" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="2" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="3" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="4" /></td>
                                                <td><input id="p24" name="p24" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>

                                                <td>
                                                    <p>25. ¿En la Institución se adelantan procesos participativos de
                                                        autoevaluación tanto institucionales como de programas
                                                        académicos?</p>
                                                </td>
                                                <td><input id="p25" name="p25" type="radio" value="0" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="1" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="2" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="3" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="4" /></td>
                                                <td><input id="p25" name="p25" type="radio" value="5" /></td>

                                            </tr>
                                            <tr>

                                                <td>26. ¿La Institución implementa e incorpora en su Plan de Desarrollo
                                                    Institucional, las propuestas de mejoramiento que surgen como
                                                    resultado de los procesos de autoevaluación?</td>
                                                <td><input id="p26" name="p26" type="radio" value="0" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="1" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="2" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="3" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="4" /></td>
                                                <td><input id="p26" name="p26" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong>PROGRAMA DE EGRESADOS</strong>
                                    </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>27. Uniclaretiana ejecuta acciones y estrategias de seguimiento
                                                    permanente a sus egresados</td>
                                                <td><input id="p27" name="p27" type="radio" value="0" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="1" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="2" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="3" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="4" /></td>
                                                <td><input id="p27" name="p27" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>28. ¿Son adecuados los canales de comunicación para divulgación de
                                                    oferta laboral con que cuenta Uniclaretiana?</td>
                                                <td><input id="p28" name="p28" type="radio" value="0" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="1" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="2" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="3" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="4" /></td>
                                                <td><input id="p28" name="p28" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>29. ¿En Uniclaretiana se tiene en cuenta las necesidades de formación de
                                                    los egresados, para ofrecer un portafolio de formación continua?
                                                </td>
                                                <td><input id="p29" name="p29" type="radio" value="0" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="1" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="2" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="3" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="4" /></td>
                                                <td><input id="p29" name="p29" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>30. ¿Las actividades de educación continua (diplomados, seminarios,
                                                    cursos y simposios y oferta de idiomas, entre otros) atienden a las
                                                    necesidades formativas de la región?</td>
                                                <td><input id="p30" name="p30" type="radio" value="0" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="1" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="2" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="3" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="4" /></td>
                                                <td><input id="p30" name="p30" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>31. ¿El programa y el área de extensión han realizado estudios e
                                                    investigaciones sobre el impacto social generado por el programa?
                                                </td>
                                                <td><input id="p31" name="p31" type="radio" value="0" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="1" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="2" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="3" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="4" /></td>
                                                <td><input id="p31" name="p31" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>32. ¿Los egresados de la institución son reconocidos en el medio por su
                                                    calidad profesional?</td>
                                                <td><input id="p32" name="p32" type="radio" value="0" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="1" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="2" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="3" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="4" /></td>
                                                <td><input id="p32" name="p32" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>33. ¿Las relaciones externas de tipo profesional, académica y de
                                                    investigación de los docentes y estudiantes, dinamizan el contenido
                                                    curricular de los programas?</td>
                                                <td><input id="p33" name="p33" type="radio" value="0" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="1" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="2" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="3" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="4" /></td>
                                                <td><input id="p33" name="p33" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> MODELO DE BIENESTAR </strong>
                                    </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>34. La Institución promueve mecanismos para mantener un clima laboral e
                                                    institucional adecuado
                                                </td>
                                                <td><input id="p34" name="p34" type="radio" value="0" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="1" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="2" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="3" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="4" /></td>
                                                <td><input id="p34" name="p34" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>35. Uniclaretiana divulga de forma efectiva las actividades de bienestar
                                                    a la comunidad universitaria
                                                </td>
                                                <td><input id="p35" name="p35" type="radio" value="0" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="1" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="2" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="3" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="4" /></td>
                                                <td><input id="p35" name="p35" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>36. Bienestar Universitario brinda servicios y actividades que
                                                    contribuyen al desarrollo personal de cada uno de los miembros de la
                                                    comunidad educativa
                                                </td>
                                                <td><input id="p36" name="p36" type="radio" value="0" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="1" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="2" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="3" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="4" /></td>
                                                <td><input id="p36" name="p36" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>37. Las acciones que se realizan en favor de la permanencia y graduación
                                                    de los estudiantes, son coherentes con la modalidad.
                                                </td>
                                                <td><input id="p37" name="p37" type="radio" value="0" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="1" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="2" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="3" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="4" /></td>
                                                <td><input id="p37" name="p37" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> RECURSOS SUFICIENTES PARA
                                            GARANTIZAR EL CUMPLIMIENTO DE LAS METAS </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>38. Los procedimientos administrativos y financieros de la Institución
                                                    se ejecutan para resolver necesidades de manera eficiente, efectiva
                                                    y eficaz.
                                                </td>
                                                <td><input id="p38" name="p38" type="radio" value="0" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="1" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="2" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="3" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="4" /></td>
                                                <td><input id="p38" name="p38" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>39. ¿En la Uniclaretiana, el presupuesto de inversión y de
                                                    funcionamiento se aplica de acuerdo con la planeación, los programas
                                                    y proyectos de cada una de las unidades académicas y administrativas
                                                    de la Universidad?
                                                </td>
                                                <td><input id="p39" name="p39" type="radio" value="0" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="1" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="2" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="3" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="4" /></td>
                                                <td><input id="p39" name="p39" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>40. Los funcionarios del área administrativa y financiera cuentan con la
                                                    experiencia necesaria para el desarrollo de sus funciones.
                                                </td>
                                                <td><input id="p40" name="p40" type="radio" value="0" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="1" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="2" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="3" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="4" /></td>
                                                <td><input id="p40" name="p40" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong> RECURSOS SUFICIENTES PARA
                                            GARANTIZAR EL CUMPLIMIENTO DE LAS METAS </strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>41. ¿Considera usted que el material bibliográfico disponible en la
                                                    biblioteca es pertinente para el desarrollo de las tareas académicas
                                                    en las diferentes áreas del conocimiento?
                                                </td>
                                                <td><input id="p41" name="p41" type="radio" value="0" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="1" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="2" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="3" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="4" /></td>
                                                <td><input id="p41" name="p41" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>42. ¿Considera usted que el material bibliográfico disponible en la
                                                    biblioteca atiende la demanda estudiantil?
                                                </td>
                                                <td><input id="p42" name="p42" type="radio" value="0" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="1" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="2" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="3" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="4" /></td>
                                                <td><input id="p42" name="p42" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>43. ¿Considera usted que el material bibliográfico disponible en la
                                                    biblioteca física y virtual se encuentra actualizado en función de
                                                    la innovación científica y tecnológica en el contexto mundial?
                                                </td>
                                                <td><input id="p43" name="p43" type="radio" value="0" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="1" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="2" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="3" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="4" /></td>
                                                <td><input id="p43" name="p43" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>44. ¿Considera usted que los sistemas de consulta de la biblioteca son
                                                    ágiles y de fácil utilización?
                                                </td>
                                                <td><input id="p44" name="p44" type="radio" value="0" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="1" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="2" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="3" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="4" /></td>
                                                <td><input id="p44" name="p44" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>45. ¿Considera usted que los equipos de cómputo (Aulas de informática)
                                                    que cuenta la Uniclaretiana para el desarrollo de las actividades
                                                    académicas están actualizados?
                                                </td>
                                                <td><input id="p45" name="p45" type="radio" value="0" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="1" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="2" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="3" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="4" /></td>
                                                <td><input id="p45" name="p45" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>46. ¿Considera usted que los equipos de cómputo (Sala de Internet
                                                    biblioteca) que cuenta la Uniclaretiana para el desarrollo de las
                                                    actividades académicas están actualizados?
                                                </td>
                                                <td><input id="p46" name="p46" type="radio" value="0" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="1" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="2" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="3" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="4" /></td>
                                                <td><input id="p46" name="p46" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>47. ¿Considera usted que los equipos audiovisuales con los que cuenta la
                                                    Universidad son suficientes?
                                                </td>
                                                <td><input id="p47" name="p47" type="radio" value="0" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="1" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="2" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="3" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="4" /></td>
                                                <td><input id="p47" name="p47" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>48. ¿Los sistemas de información institucional son eficientes?
                                                </td>
                                                <td><input id="p48" name="p48" type="radio" value="0" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="1" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="2" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="3" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="4" /></td>
                                                <td><input id="p48" name="p48" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>49. ¿Los mecanismos de comunicación institucional son eficientes?
                                                </td>
                                                <td><input id="p49" name="p49" type="radio" value="0" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="1" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="2" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="3" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="4" /></td>
                                                <td><input id="p49" name="p49" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>50. ¿La tecnología para garantizar una adecuada conectividad a los
                                                    miembros de la comunidad académica es eficiente?
                                                </td>
                                                <td><input id="p50" name="p50" type="radio" value="0" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="1" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="2" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="3" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="4" /></td>
                                                <td><input id="p50" name="p50" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>51. ¿Los laboratorios para desempeñar las tareas académicas de la
                                                    institución son de calidad?
                                                </td>
                                                <td><input id="p51" name="p51" type="radio" value="0" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="1" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="2" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="3" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="4" /></td>
                                                <td><input id="p51" name="p51" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>52. ¿Los laboratorios para desempeñar las tareas académicas de la
                                                    institución son pertinentes?
                                                </td>
                                                <td><input id="p52" name="p52" type="radio" value="0" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="1" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="2" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="3" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="4" /></td>
                                                <td><input id="p52" name="p52" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="d-flex justify-content-center">
                                <div class="form-group">
                                    <p class="card-text font-italic text-justify"><strong>Califique, en términos
                                            generales, las características de la planta física de la
                                            Universidad:</strong> </p>
                                    <table class="table table-bordered " style="width:100%;">
                                        <thead class="bg-dark text-white">
                                            <tr>

                                                <th>PREGUNTAS </th>
                                                <th class="text-center">0</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-align: justify">
                                            <tr>
                                                <td>53. Suficiencia de espacios
                                                </td>
                                                <td><input id="p53" name="p53" type="radio" value="0" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="1" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="2" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="3" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="4" /></td>
                                                <td><input id="p53" name="p53" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>54. Distribución de espacios
                                                </td>
                                                <td><input id="p54" name="p54" type="radio" value="0" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="1" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="2" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="3" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="4" /></td>
                                                <td><input id="p54" name="p54" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>55. Facilidad de acceso
                                                </td>
                                                <td><input id="p55" name="p55" type="radio" value="0" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="1" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="2" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="3" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="4" /></td>
                                                <td><input id="p55" name="p55" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>56. Iluminación
                                                </td>
                                                <td><input id="p56" name="p56" type="radio" value="0" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="1" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="2" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="3" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="4" /></td>
                                                <td><input id="p56" name="p56" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>57. Ventilación
                                                </td>
                                                <td><input id="p57" name="p57" type="radio" value="0" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="1" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="2" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="3" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="4" /></td>
                                                <td><input id="p57" name="p57" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>58. Limpieza
                                                </td>
                                                <td><input id="p58" name="p58" type="radio" value="0" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="1" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="2" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="3" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="4" /></td>
                                                <td><input id="p58" name="p58" type="radio" value="5" /></td>
                                            </tr>
                                            <tr>
                                                <td>59. Condiciones de seguridad
                                                </td>
                                                <td><input id="p59" name="p59" type="radio" value="0" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="1" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="2" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="3" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="4" /></td>
                                                <td><input id="p59" name="p59" type="radio" value="5" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                            <button type="submit" id="btnGuardar" name="btnGuardar" class="btn btn-dark">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/vue@2.x/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.js"></script>
    <script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
    <script src="../../../dashboar/vendor/jquery/jquery.min.js"></script>
    <script src="../../../dashboar/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../../../dashboar/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../../../dashboar/js/sb-admin-2.min.js"></script>

</body>

</html>