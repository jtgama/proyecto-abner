<?php
include "../conexion.php";

 


function obtenerCondiciones() {
    $objeto = new Conexion();
    $conexion = $objeto->Conectar();
    $query = "SELECT * FROM condiciones";
    $result = $conexion->query($query);
   
     $json = array();
     
     while($row = $result->fetch()) {
         $json[] = array(
             'codCondicion' => $row['ID'],
             'nomCondicion' => $row['CONDICION'],
         );
     }  
 
     $jsonstring = json_encode($json);
     echo $jsonstring;
 }
 
 

    function  obtenerAspectos($codapectos) {
       
        $objeto = new Conexion();
        $conexion = $objeto->Conectar();

        $query = "SELECT * FROM aspectos WHERE CONDICIONES_ID = $codapectos";
        $result = $conexion->query($query);

        $json = array();
        
        while($row = $result->fetch()) {
            $json[] = array(
                'codAspecto' => $row['ID'],
                'nomAspecto' => $row['ASPECTO'],
            );
        }

        $jsonstring = json_encode($json);
        echo $jsonstring;
    }

    function  obtenerIndicadores($codIndicadores) {
       
        $objeto = new Conexion();
        $conexion = $objeto->Conectar();

        $query = "SELECT * FROM indicador WHERE ASPECTOS_ID = $codIndicadores";
        $result = $conexion->query($query);

        $json = array();
        
        while($row = $result->fetch()) {
            $json[] = array(
                'codIndicador' => $row['ID'],
                'nomIndicador' => $row['INDICADOR'],
            );
        }

        $jsonstring = json_encode($json);
        echo $jsonstring;
    }
    
    if( isset($_POST['codigoAspecto']) ) {
        $codapectos = $_POST['codigoAspecto'];
        obtenerAspectos($codapectos);
   
    }else if( isset($_POST['codigoIndica']) ) {
        $codCC = $_POST['codigoIndica'];
        obtenerIndicadores($codCC);
    }
    else{
        obtenerCondiciones();        
    }

    