<?php
include_once '../conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

if (isset($_POST['btnGuardar'])) {
    echo 'ok';
    $idPrograma = trim($_POST['idPrograma']);
    $preguntas[0] = trim($_POST['p1']);
    $preguntas[1] = trim($_POST['p2']);
    $preguntas[2] = trim($_POST['p3']);
    $preguntas[3] = trim($_POST['p4']);
    $preguntas[4] = trim($_POST['p5']);
    $preguntas[5] = trim($_POST['p6']);
    $preguntas[6] = trim($_POST['p7']);
    $preguntas[7] = trim($_POST['p8']);
    $preguntas[8] = trim($_POST['p9']);
    $preguntas[9] = trim($_POST['p10']);
    $preguntas[10] = trim($_POST['p11']);
    $preguntas[11] = trim($_POST['p12']);
    $preguntas[12] = trim($_POST['p13']);
    $preguntas[13] = trim($_POST['p14']);
    $preguntas[14] = trim($_POST['p15']);
    $preguntas[15] = trim($_POST['p16']);
    $preguntas[16] = trim($_POST['p17']);
    $preguntas[17] = trim($_POST['p18']);
    $preguntas[18] = trim($_POST['p19']);
    $preguntas[19] = trim($_POST['p20']);
    $preguntas[20] = trim($_POST['p21']);
    $preguntas[21] = trim($_POST['p22']);
    $preguntas[22] = trim($_POST['p23']);
    $preguntas[23] = trim($_POST['p24']);
    $preguntas[24] = trim($_POST['p25']);
    $preguntas[25] = trim($_POST['p26']);
    $preguntas[26] = trim($_POST['p27']);
    $preguntas[27] = trim($_POST['p28']);
    $preguntas[28] = trim($_POST['p29']);
    $preguntas[29] = trim($_POST['p30']);
    $preguntas[30] = trim($_POST['p31']);
    $preguntas[31] = trim($_POST['p32']);
    
    $consulta = "call acabacom_fucla.add_encuesta_egresados(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, @pRESULTADO)";
    $resultado = $conexion->prepare($consulta);
    $resultado->bindParam(1, $pIdPrograma);
    $resultado->bindParam(2, $pPreguntas[0]);
    $resultado->bindParam(3, $pPreguntas[1]);
    $resultado->bindParam(4, $pPreguntas[2]);
    $resultado->bindParam(5, $pPreguntas[3]);
    $resultado->bindParam(6, $pPreguntas[4]);
    $resultado->bindParam(7, $pPreguntas[5]);
    $resultado->bindParam(8, $pPreguntas[6]);
    $resultado->bindParam(9, $pPreguntas[7]);
    $resultado->bindParam(10, $pPreguntas[8]);
    $resultado->bindParam(11, $pPreguntas[9]);
    $resultado->bindParam(12, $pPreguntas[10]);
    $resultado->bindParam(13, $pPreguntas[11]);
    $resultado->bindParam(14, $pPreguntas[12]);
    $resultado->bindParam(15, $pPreguntas[13]);
    $resultado->bindParam(16, $pPreguntas[14]);
    $resultado->bindParam(17, $pPreguntas[15]);
    $resultado->bindParam(18, $pPreguntas[16]);
    $resultado->bindParam(19, $pPreguntas[17]);
    $resultado->bindParam(20, $pPreguntas[18]);
    $resultado->bindParam(21, $pPreguntas[19]);
    $resultado->bindParam(22, $pPreguntas[20]);
    $resultado->bindParam(23, $pPreguntas[21]);
    $resultado->bindParam(24, $pPreguntas[22]);
    $resultado->bindParam(25, $pPreguntas[23]);
    $resultado->bindParam(26, $pPreguntas[24]);
    $resultado->bindParam(27, $pPreguntas[25]);
    $resultado->bindParam(28, $pPreguntas[26]);
    $resultado->bindParam(29, $pPreguntas[27]);
    $resultado->bindParam(30, $pPreguntas[28]);
    $resultado->bindParam(31, $pPreguntas[29]);
    $resultado->bindParam(32, $pPreguntas[30]);
    $resultado->bindParam(33, $pPreguntas[31]);
    $pIdPrograma = (int) $idPrograma;
    $pPreguntas[0] = $preguntas[0];
    $pPreguntas[1] = $preguntas[1];
    $pPreguntas[2] = $preguntas[2];
    $pPreguntas[3] = $preguntas[3];
    $pPreguntas[4] = $preguntas[4];
    $pPreguntas[5] = $preguntas[5];
    $pPreguntas[6] = $preguntas[6];
    $pPreguntas[7] = $preguntas[7];
    $pPreguntas[8] = $preguntas[8];
    $pPreguntas[9] = $preguntas[9];
    $pPreguntas[10] = $preguntas[10];
    $pPreguntas[11] = $preguntas[11];
    $pPreguntas[12] = $preguntas[12];
    $pPreguntas[13] = $preguntas[13];
    $pPreguntas[14] = $preguntas[14];
    $pPreguntas[15] = $preguntas[15];
    $pPreguntas[16] = $preguntas[16];
    $pPreguntas[17] = $preguntas[17];
    $pPreguntas[18] = $preguntas[18];
    $pPreguntas[19] = $preguntas[19];
    $pPreguntas[20] = $preguntas[20];
    $pPreguntas[21] = $preguntas[21];
    $pPreguntas[22] = $preguntas[22];
    $pPreguntas[23] = $preguntas[23];
    $pPreguntas[24] = $preguntas[24];
    $pPreguntas[25] = $preguntas[25];
    $pPreguntas[26] = $preguntas[26];
    $pPreguntas[27] = $preguntas[27];
    $pPreguntas[28] = $preguntas[28];
    $pPreguntas[29] = $preguntas[29];
    $pPreguntas[30] = $preguntas[30];
    $pPreguntas[31] = $preguntas[31];

    $resultado->execute(); 
    $resultado->closeCursor();
    $r = $conexion->query('select @pResultado'); 
    $result = $r->fetchColumn();
    switch ($result) {

        case '200':
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

            <script>
            $( document ).ready(function() {
                Swal.fire({
                    icon:"success",
                    title:"¡REGISTRO DE LA ENCUESTA REALIZADA EXITOSAMENTE!",
                    text: "Su Datos Se Guardaron Corectamente",
                    confirmButtonColor:"#4AEE08",
                    confirmButtonText:"Continuar.."
                }).then((result) => {
                    if(result.value){

                        window.location.href = "../../dashboar/index.php";
                    }
                });

            });
            </script>';
            break;
        case '404':
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

                <script>
                $( document ).ready(function() {
                    Swal.fire({
                        icon:"warning",
                        title:" ERROR - AL GUARDAR EL REGISTRO, COMUNIQUESE CON EL ÁREA DE TI",
                        confirmButtonColor:"#7108EE",
                        confirmButtonText:"Continuar.."
                    }).then((result) => {
                        if(result.value){

                            window.location.href = "../../dashboar/index.php";
                        }
                    });

                });
                </script>';
            break;

        default:
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

        <script>
        $( document ).ready(function() {
            Swal.fire({
                icon:"error",
                title:"ERROR DE REGISTRO",
                text: "Su Datos No fueron Registrado.",
                confirmButtonColor:"#EE2408",
                confirmButtonText:"Continuar.."
            }).then((result) => {
                if(result.value){

                    window.location.href = "../../dashboar/index.php";
                }
            });

        });
        </script>';
            break;
    }
}else{
    echo '
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
    $( document ).ready(function() {
        Swal.fire({
            icon:"error",
            title:"ERROR",
            text: "El Formulario no Se esta Validando",
            confirmButtonColor:"#EE2408",
            confirmButtonText:"Continuar.."
        }).then((result) => {
            if(result.value){

                window.location.href = "../../dashboar/index.php";
            }
        });

    });
    </script>';
}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;