<?php
include_once '../conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

if (isset($_POST['btnGuardar'])) {
    echo 'ok';
    $idPrograma = trim($_POST['idPrograma']);
    $fecha_ini = trim($_POST['fecha_ini']);
    $convert_fini = date("Y-m-d", strtotime($fecha_ini));
    $fecha_fin = trim($_POST['fecha_fin']);
    $convert_ffin = date("Y-m-d", strtotime($fecha_fin));

    $consulta = "call acabacom_fucla.add_encuestas(?, ?, ?, @pRESULTADO)";
    $resultado = $conexion->prepare($consulta);
    $resultado->bindParam(1, $pIdPrograma);
    $resultado->bindParam(2, $convert_fini);
    $resultado->bindParam(3, $convert_ffin);
    $pIdPrograma = (int) $idPrograma;
    $pConvert_fini = $convert_fini;
    $pConvert_ffin = $convert_ffin;
    $resultado->execute(); 
    $resultado->closeCursor();
    $r = $conexion->query('select @pResultado'); 
    $result = $r->fetchColumn();
    switch ($result) {

        case '200':
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

            <script>
            $( document ).ready(function() {
                Swal.fire({
                    icon:"success",
                    title:"¡REGISTRO DE LA ENCUESTA REALIZADA EXITOSAMENTE!",
                    text: "Su Datos Se Guardaron Corectamente",
                    confirmButtonColor:"#4AEE08",
                    confirmButtonText:"Continuar.."
                }).then((result) => {
                    if(result.value){

                        window.location.href = "../../dashboar/views/add_encuesta.php";
                    }
                });

            });
            </script>';
            break;
        case '404':
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

                <script>
                $( document ).ready(function() {
                    Swal.fire({
                        icon:"warning",
                        title:" ERROR - AL GUARDAR EL REGISTRO, COMUNIQUESE CON EL ÁREA DE TI",
                        confirmButtonColor:"#7108EE",
                        confirmButtonText:"Continuar.."
                    }).then((result) => {
                        if(result.value){

                            window.location.href = "../../dashboar/views/add_encuesta.php";
                        }
                    });

                });
                </script>';
            break;

        default:
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

        <script>
        $( document ).ready(function() {
            Swal.fire({
                icon:"error",
                title:"ERROR DE REGISTRO",
                text: "Su Datos No fueron Registrado.",
                confirmButtonColor:"#EE2408",
                confirmButtonText:"Continuar.."
            }).then((result) => {
                if(result.value){

                    window.location.href = "../../dashboar/views/add_encuesta.php";
                }
            });

        });
        </script>';
            break;
    }
}else{
    echo '
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
    $( document ).ready(function() {
        Swal.fire({
            icon:"error",
            title:"ERROR",
            text: "El Formulario no Se esta Validando",
            confirmButtonColor:"#EE2408",
            confirmButtonText:"Continuar.."
        }).then((result) => {
            if(result.value){

                window.location.href = "../../dashboar/views/add_encuesta.php";
            }
        });

    });
    </script>';
}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;