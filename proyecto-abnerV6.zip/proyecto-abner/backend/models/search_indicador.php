<?php
include "../../backend/conexion.php";
$objeto = new Conexion();
$conexion = $objeto->Conectar();


if (isset($_POST['btnGuardar'])) {

 $programa = $_POST['programas'];
 $condicion = $_POST['condiciones'];
 $aspecto = $_POST['aspectos'];
 $indicador = $_POST['indicadores'];
  $modalidad = $_POST['modalidades'];
  $fechaini = $_POST['fecha_ini'];  
    $query = "SELECT inds.ID AS ID,
    cnd.CONDICION AS CONDICION,
    asp.ASPECTO AS ASPECTO, 
    ind.INDICADOR AS INDICADOR, 
    moda.NOMBRE AS MODALIDAD,
    prm.NOMBRE AS PROGRAMA, 
    evi.FCHA_CREACION AS FECHA,
    inds.DOCUMENTO AS DOCUMENTO 
    FROM acabacom_fucla.indicadores inds
    INNER JOIN acabacom_fucla.indicador ind ON inds.INDICADOR_ID = ind.ID
    INNER JOIN acabacom_fucla.aspectos asp ON ind.ASPECTOS_ID = asp.ID
    INNER JOIN acabacom_fucla.condiciones cnd ON asp.CONDICIONES_ID = cnd.ID
    INNER JOIN acabacom_fucla.evidencias evi ON inds.EVIDENCIAS_ID = evi.ID
    INNER JOIN acabacom_fucla.programa prm ON evi.PROGRAMA_ID = prm.ID
    INNER JOIN acabacom_fucla.modalidad moda ON prm.MODALIDAD_ID = moda.ID
    WHERE cnd.ID = '".$condicion."' AND asp.ID = '".$aspecto."' AND ind.ID = '".$indicador."' AND moda.ID = '".$modalidad."' AND prm.ID = '".$programa."' AND YEAR('".$fechaini."') = YEAR('".$fechaini."') AND MONTH('".$fechaini."') = MONTH('".$fechaini."')";
  
    $result = $conexion->query($query);

    $json = array();
    if ($result->rowCount() > 0) {
      while($row = $result->fetch()) {
        $json[] = array(
            'idindica' => $row['ID'],
            'modalidad' => $row['MODALIDAD'],
            'programa' => $row['PROGRAMA'],
            'condicion' => $row['CONDICION'],
            'aspecto' => $row['ASPECTO'],
            'indicador' => $row['INDICADOR'],
            'fecha' => $row['FECHA'],
            'documento' => $row['DOCUMENTO'],
            
        );
    }

    $jsonstring = json_encode($json);
  }
  else{
          
    echo '
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
   
  
  <script>
  $( document ).ready(function() {
    Swal.fire({
        icon:"warning",
        title:"Error de Busqueda",
        text: "El Indicador No Existe"
    }).then((result) => {
        if(result.value){
  
            window.location.href = "add_indicadores.php";
        }
    });
  
  });
  </script>';
  
  
  }      
   
    #echo $jsonstring;
}
else if(isset($_POST['btnGuardarA'])){   
    setlocale(LC_TIME, "spanish");
    $id2= trim($_POST['id']);
    $directorio = 'upload/';
    
    

    $today = strftime("%d de %B de %Y");
    if (!file_exists($directorio)) 
      {
        mkdir($directorio, 0777, true);
      }
      
        $planme1  =  $_FILES["file"]["name"];
        $archivo = $directorio." - ".$today ." - ". basename($_FILES["file"]["name"]);
    
        $resulta = move_uploaded_file($_FILES["file"] ["tmp_name"], $archivo);
                
        
        $consulta = "UPDATE acabacom_fucla.indicadores set DOCUMENTO = ? Where ID = ?";
        $resultado = $conexion->prepare($consulta);
        $resultado2 =  $resultado->execute([$archivo,$id2]); # Pasar en el mismo orden de los ?
        $resultado->closeCursor();   
        
       

       
        
        if($resultado->rowCount() > 0)
        {
        $count = $resultado->rowCount(); 
                  
        echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
           
            <script>
            $( document ).ready(function() {
                Swal.fire({
                    type:"success",
                    title:"¡ACTUALIZACION EXITOSA!",
                    confirmButtonColor:"#3085d6",
                    confirmButtonText:"Continuar.."
                }).then((result) => {
                    if(result.value){
                       
                        window.location.href = "add_indicadores.php";
                    }
                });
                
            });
            </script>';
        }
        else{
        
          echo '
          <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
          <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
         

      <script>
      $( document ).ready(function() {
          Swal.fire({
              type:"error",
              title:"ERROR DE REGISTRO"
          }).then((result) => {
              if(result.value){

                  window.location.href = "add_indicadores.php";
              }
          });

      });
      </script>';
      
        print_r($resultado->errorInfo()); 
        } 
}
else{
        
  echo '
  <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
 

<script>
$( document ).ready(function() {
  Swal.fire({
      type:"error",
      title:"ERROR DE REGISTRO"
  }).then((result) => {
      if(result.value){

          window.location.href = "add_indicadores.php";
      }
  });

});
</script>';


}      

?>