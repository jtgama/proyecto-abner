<?php
include_once '../conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

if (isset($_POST['btnGuardar'])) {
    echo 'ok';
    $nis = trim($_POST['nis']);
    $idPrograma = trim($_POST['idPrograma']);
    $codRC = trim($_POST['codRC']);
    $fecha_RC = trim($_POST['fecha_RC']);
    $convert_fRC = date("Y-m-d", strtotime($fecha_RC));

    $consulta = "call acabacom_fucla.add_semaforo_rc(?, ?, ?, ?, @pRESULTADO)";
    $resultado = $conexion->prepare($consulta);
    $resultado->bindParam(1, $pNis);
    $resultado->bindParam(2, $pIdPrograma);
    $resultado->bindParam(3, $pCodRC);
    $resultado->bindParam(4, $pConvert_fRC);
    $pNis = (int) $nis;
    $pIdPrograma = (int) $idPrograma;
    $pCodRC = $codRC;
    $pConvert_fRC = $convert_fRC;
    $resultado->execute(); 
    $resultado->closeCursor();
    $r = $conexion->query('select @pResultado'); 
    $result = $r->fetchColumn();
    switch ($result) {

        case '200':
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

            <script>
            $( document ).ready(function() {
                Swal.fire({
                    icon:"success",
                    title:"¡REGISTRO DE LA RESOLUCIÓN DE RC REALIZADA EXITOSAMENTE!",
                    text: "Su Datos Se Guardaron Corectamente",
                    confirmButtonColor:"#4AEE08",
                    confirmButtonText:"Continuar.."
                }).then((result) => {
                    if(result.value){

                        window.location.href = "add_semaforo.php";
                    }
                });

            });
            </script>';
            break;
        case '404':
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

                <script>
                $( document ).ready(function() {
                    Swal.fire({
                        icon:"warning",
                        title:" YA EXISTE UN RC REGISTRADO CON ESE NIS DE IDENTIFICACIÓN O NO EXISTE UN PROGRAMA RELACIONADO CON EL NIS INGRESADO",
                        confirmButtonColor:"#7108EE",
                        confirmButtonText:"Continuar.."
                    }).then((result) => {
                        if(result.value){

                            window.location.href = "add_semaforo.php";
                        }
                    });

                });
                </script>';
            break;

        default:
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

        <script>
        $( document ).ready(function() {
            Swal.fire({
                icon:"error",
                title:"ERROR DE REGISTRO",
                text: "Su Datos No fueron Registrado.",
                confirmButtonColor:"#EE2408",
                confirmButtonText:"Continuar.."
            }).then((result) => {
                if(result.value){

                    window.location.href = "add_semaforo.php";
                }
            });

        });
        </script>';
            break;
    }

}else{
    echo '
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
    $( document ).ready(function() {
        Swal.fire({
            icon:"error",
            title:"ERROR",
            text: "El Formulario no Se esta Validando",
            confirmButtonColor:"#EE2408",
            confirmButtonText:"Continuar.."
        }).then((result) => {
            if(result.value){

                window.location.href = "add_semaforo.php";
            }
        });

    });
    </script>';
}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;