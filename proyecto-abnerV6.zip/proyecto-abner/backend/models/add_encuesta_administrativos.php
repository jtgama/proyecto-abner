<?php
include_once '../conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

if (isset($_POST['btnGuardar'])) {
    echo 'ok';
    $idPrograma = trim($_POST['idPrograma']);
    $preguntas[0] = trim($_POST['p1']);
    $preguntas[1] = trim($_POST['p2']);
    $preguntas[2] = trim($_POST['p3']);
    $preguntas[3] = trim($_POST['p4']);
    $preguntas[4] = trim($_POST['p5']);
    $preguntas[5] = trim($_POST['p6']);
    $preguntas[6] = trim($_POST['p7']);
    $preguntas[7] = trim($_POST['p8']);
    $preguntas[8] = trim($_POST['p9']);
    $preguntas[9] = trim($_POST['p10']);
    $preguntas[10] = trim($_POST['p11']);
    $preguntas[11] = trim($_POST['p12']);
    $preguntas[12] = trim($_POST['p13']);
    $preguntas[13] = trim($_POST['p14']);
    $preguntas[14] = trim($_POST['p15']);
    $preguntas[15] = trim($_POST['p16']);
    $preguntas[16] = trim($_POST['p17']);
    $preguntas[17] = trim($_POST['p18']);
    $preguntas[18] = trim($_POST['p19']);
    $preguntas[19] = trim($_POST['p20']);
    $preguntas[20] = trim($_POST['p21']);
    $preguntas[21] = trim($_POST['p22']);
    $preguntas[22] = trim($_POST['p23']);
    $preguntas[23] = trim($_POST['p24']);
    $preguntas[24] = trim($_POST['p25']);
    $preguntas[25] = trim($_POST['p26']);
    $preguntas[26] = trim($_POST['p27']);
    $preguntas[27] = trim($_POST['p28']);
    $preguntas[28] = trim($_POST['p29']);
    $preguntas[29] = trim($_POST['p30']);
    $preguntas[30] = trim($_POST['p31']);
    $preguntas[31] = trim($_POST['p32']);
    $preguntas[32] = trim($_POST['p33']);
    $preguntas[33] = trim($_POST['p34']);
    $preguntas[34] = trim($_POST['p35']);
    $preguntas[35] = trim($_POST['p36']);
    $preguntas[36] = trim($_POST['p37']);
    $preguntas[37] = trim($_POST['p38']);
    $preguntas[38] = trim($_POST['p39']);
    $preguntas[39] = trim($_POST['p40']);
    $preguntas[40] = trim($_POST['p41']);
    $preguntas[41] = trim($_POST['p42']);
    $preguntas[42] = trim($_POST['p43']);
    $preguntas[43] = trim($_POST['p44']);
    $preguntas[44] = trim($_POST['p45']);
    $preguntas[45] = trim($_POST['p46']);
    $preguntas[46] = trim($_POST['p47']);
    $preguntas[47] = trim($_POST['p48']);
    $preguntas[48] = trim($_POST['p49']);
    $preguntas[49] = trim($_POST['p50']);
    $preguntas[50] = trim($_POST['p51']);
    $preguntas[51] = trim($_POST['p52']);
    $preguntas[52] = trim($_POST['p53']);
    $preguntas[53] = trim($_POST['p54']);
    $preguntas[54] = trim($_POST['p55']);
    $preguntas[55] = trim($_POST['p56']);
    $preguntas[56] = trim($_POST['p57']);
    $preguntas[57] = trim($_POST['p58']);
    $preguntas[58] = trim($_POST['p59']);
    
    $consulta = "call acabacom_fucla.add_encuesta_administrativos(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, @pRESULTADO)";
    $resultado = $conexion->prepare($consulta);
    $resultado->bindParam(1, $pIdPrograma);
    $resultado->bindParam(2, $pPreguntas[0]);
    $resultado->bindParam(3, $pPreguntas[1]);
    $resultado->bindParam(4, $pPreguntas[2]);
    $resultado->bindParam(5, $pPreguntas[3]);
    $resultado->bindParam(6, $pPreguntas[4]);
    $resultado->bindParam(7, $pPreguntas[5]);
    $resultado->bindParam(8, $pPreguntas[6]);
    $resultado->bindParam(9, $pPreguntas[7]);
    $resultado->bindParam(10, $pPreguntas[8]);
    $resultado->bindParam(11, $pPreguntas[9]);
    $resultado->bindParam(12, $pPreguntas[10]);
    $resultado->bindParam(13, $pPreguntas[11]);
    $resultado->bindParam(14, $pPreguntas[12]);
    $resultado->bindParam(15, $pPreguntas[13]);
    $resultado->bindParam(16, $pPreguntas[14]);
    $resultado->bindParam(17, $pPreguntas[15]);
    $resultado->bindParam(18, $pPreguntas[16]);
    $resultado->bindParam(19, $pPreguntas[17]);
    $resultado->bindParam(20, $pPreguntas[18]);
    $resultado->bindParam(21, $pPreguntas[19]);
    $resultado->bindParam(22, $pPreguntas[20]);
    $resultado->bindParam(23, $pPreguntas[21]);
    $resultado->bindParam(24, $pPreguntas[22]);
    $resultado->bindParam(25, $pPreguntas[23]);
    $resultado->bindParam(26, $pPreguntas[24]);
    $resultado->bindParam(27, $pPreguntas[25]);
    $resultado->bindParam(28, $pPreguntas[26]);
    $resultado->bindParam(29, $pPreguntas[27]);
    $resultado->bindParam(30, $pPreguntas[28]);
    $resultado->bindParam(31, $pPreguntas[29]);
    $resultado->bindParam(32, $pPreguntas[30]);
    $resultado->bindParam(33, $pPreguntas[31]);
    $resultado->bindParam(34, $pPreguntas[32]);
    $resultado->bindParam(35, $pPreguntas[33]);
    $resultado->bindParam(36, $pPreguntas[34]);
    $resultado->bindParam(37, $pPreguntas[35]);
    $resultado->bindParam(38, $pPreguntas[36]);
    $resultado->bindParam(39, $pPreguntas[37]);
    $resultado->bindParam(40, $pPreguntas[38]);
    $resultado->bindParam(41, $pPreguntas[39]);
    $resultado->bindParam(42, $pPreguntas[40]);
    $resultado->bindParam(43, $pPreguntas[41]);
    $resultado->bindParam(44, $pPreguntas[42]);
    $resultado->bindParam(45, $pPreguntas[43]);
    $resultado->bindParam(46, $pPreguntas[44]);
    $resultado->bindParam(47, $pPreguntas[45]);
    $resultado->bindParam(48, $pPreguntas[46]);
    $resultado->bindParam(49, $pPreguntas[47]);
    $resultado->bindParam(50, $pPreguntas[48]);
    $resultado->bindParam(51, $pPreguntas[49]);
    $resultado->bindParam(52, $pPreguntas[50]);
    $resultado->bindParam(53, $pPreguntas[51]);
    $resultado->bindParam(54, $pPreguntas[52]);
    $resultado->bindParam(55, $pPreguntas[53]);
    $resultado->bindParam(56, $pPreguntas[54]);
    $resultado->bindParam(57, $pPreguntas[55]);
    $resultado->bindParam(58, $pPreguntas[56]);
    $resultado->bindParam(59, $pPreguntas[57]);
    $resultado->bindParam(60, $pPreguntas[58]);
    $pIdPrograma = (int) $idPrograma;
    $pPreguntas[0] = $preguntas[0];
    $pPreguntas[1] = $preguntas[1];
    $pPreguntas[2] = $preguntas[2];
    $pPreguntas[3] = $preguntas[3];
    $pPreguntas[4] = $preguntas[4];
    $pPreguntas[5] = $preguntas[5];
    $pPreguntas[6] = $preguntas[6];
    $pPreguntas[7] = $preguntas[7];
    $pPreguntas[8] = $preguntas[8];
    $pPreguntas[9] = $preguntas[9];
    $pPreguntas[10] = $preguntas[10];
    $pPreguntas[11] = $preguntas[11];
    $pPreguntas[12] = $preguntas[12];
    $pPreguntas[13] = $preguntas[13];
    $pPreguntas[14] = $preguntas[14];
    $pPreguntas[15] = $preguntas[15];
    $pPreguntas[16] = $preguntas[16];
    $pPreguntas[17] = $preguntas[17];
    $pPreguntas[18] = $preguntas[18];
    $pPreguntas[19] = $preguntas[19];
    $pPreguntas[20] = $preguntas[20];
    $pPreguntas[21] = $preguntas[21];
    $pPreguntas[22] = $preguntas[22];
    $pPreguntas[23] = $preguntas[23];
    $pPreguntas[24] = $preguntas[24];
    $pPreguntas[25] = $preguntas[25];
    $pPreguntas[26] = $preguntas[26];
    $pPreguntas[27] = $preguntas[27];
    $pPreguntas[28] = $preguntas[28];
    $pPreguntas[29] = $preguntas[29];
    $pPreguntas[30] = $preguntas[30];
    $pPreguntas[31] = $preguntas[31];
    $pPreguntas[32] = $preguntas[32];
    $pPreguntas[33] = $preguntas[33];
    $pPreguntas[34] = $preguntas[34];
    $pPreguntas[35] = $preguntas[35];
    $pPreguntas[36] = $preguntas[36];
    $pPreguntas[37] = $preguntas[37];
    $pPreguntas[38] = $preguntas[38];
    $pPreguntas[39] = $preguntas[39];
    $pPreguntas[40] = $preguntas[40];
    $pPreguntas[41] = $preguntas[41];
    $pPreguntas[42] = $preguntas[42];
    $pPreguntas[43] = $preguntas[43];
    $pPreguntas[44] = $preguntas[44];
    $pPreguntas[45] = $preguntas[45];
    $pPreguntas[46] = $preguntas[46];
    $pPreguntas[47] = $preguntas[47];
    $pPreguntas[48] = $preguntas[48];
    $pPreguntas[49] = $preguntas[49];
    $pPreguntas[50] = $preguntas[50];
    $pPreguntas[51] = $preguntas[51];
    $pPreguntas[52] = $preguntas[52];
    $pPreguntas[53] = $preguntas[53];
    $pPreguntas[54] = $preguntas[54];
    $pPreguntas[55] = $preguntas[55];
    $pPreguntas[56] = $preguntas[56];
    $pPreguntas[57] = $preguntas[57];
    $pPreguntas[58] = $preguntas[58];

    $resultado->execute(); 
    $resultado->closeCursor();
    $r = $conexion->query('select @pResultado'); 
    $result = $r->fetchColumn();
    switch ($result) {

        case '200':
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

            <script>
            $( document ).ready(function() {
                Swal.fire({
                    icon:"success",
                    title:"¡REGISTRO DE LA RESOLUCIÓN DE RC REALIZADA EXITOSAMENTE!",
                    text: "Su Datos Se Guardaron Corectamente",
                    confirmButtonColor:"#4AEE08",
                    confirmButtonText:"Continuar.."
                }).then((result) => {
                    if(result.value){

                        window.location.href = "../../dashboar/index.php";
                    }
                });

            });
            </script>';
            break;
        case '404':
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

                <script>
                $( document ).ready(function() {
                    Swal.fire({
                        icon:"warning",
                        title:" ERROR - AL GUARDAR EL REGISTRO, COMUNIQUESE CON EL ÁREA DE TI",
                        confirmButtonColor:"#7108EE",
                        confirmButtonText:"Continuar.."
                    }).then((result) => {
                        if(result.value){

                            window.location.href = "../../dashboar/index.php";
                        }
                    });

                });
                </script>';
            break;

        default:
            echo '
            <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

        <script>
        $( document ).ready(function() {
            Swal.fire({
                icon:"error",
                title:"ERROR DE REGISTRO",
                text: "Su Datos No fueron Registrado.",
                confirmButtonColor:"#EE2408",
                confirmButtonText:"Continuar.."
            }).then((result) => {
                if(result.value){

                    window.location.href = "../../dashboar/index.php";
                }
            });

        });
        </script>';
            break;
    }
}else{
    echo '
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
    $( document ).ready(function() {
        Swal.fire({
            icon:"error",
            title:"ERROR",
            text: "El Formulario no Se esta Validando",
            confirmButtonColor:"#EE2408",
            confirmButtonText:"Continuar.."
        }).then((result) => {
            if(result.value){

                window.location.href = "../../dashboar/index.php";
            }
        });

    });
    </script>';
}



//print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;